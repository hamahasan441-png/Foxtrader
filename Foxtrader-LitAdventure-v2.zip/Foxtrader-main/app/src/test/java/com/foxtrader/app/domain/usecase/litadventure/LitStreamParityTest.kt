package com.foxtrader.app.domain.usecase.litadventure

import com.foxtrader.app.domain.model.Candle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/**
 * The streaming engine is only safe to use if it is indistinguishable from the
 * batch engine. This test is the guarantee.
 *
 * If it fails, [LitStreamEngine] is wrong. Do not relax the assertions to make
 * it pass — a fast engine that disagrees with the specification is worse than a
 * slow one that does not, because the disagreement will show up as trades.
 *
 * Why this matters for performance: the batch analyzer is called once per bar by
 * the backtester, which is O(n * window). Measured on the reference
 * implementation, that costs 252x more than streaming at n = 4,000, and the
 * ratio grows linearly with n.
 */
class LitStreamParityTest {

    private val pullbacks = LitPullbackEngine()
    private val structure = LitAdventureStructure()
    private val poi = LitPoiDetector()
    private val streamEngine = LitStreamEngine()

    /** Alternating-drift series: produces BOS, CHoCH, inducements and sweeps. */
    private fun series(count: Int, seed: Int): List<Candle> {
        val rng = Random(seed)
        var price = 1.1000
        var timestamp = 1_700_000_000_000L
        return (0 until count).map { i ->
            val drift = if ((i / 25) % 2 == 0) 0.00006 else -0.00006
            val open = price
            var high = open
            var low = open
            var close = open
            repeat(4) {
                close += drift + (rng.nextDouble() - 0.5) * 0.00024
                high = maxOf(high, close)
                low = minOf(low, close)
            }
            price = close
            timestamp += 300_000L
            Candle(timestamp, open, high, low, close, 100.0)
        }
    }

    private fun assertParity(seed: Int, count: Int = 1500) {
        val candles = series(count, seed)

        val stream = streamEngine.replay(candles)

        val effective = pullbacks.buildEffective(candles)
        val swings = pullbacks.detectSwings(effective)
        val batchStructure = structure.run(effective, swings)
        val batchFvgs = poi.findFvgs(effective)
        val batchBlocks = poi.findOrderBlocks(effective, batchFvgs)
        val batchScobs = poi.findScobs(effective)

        assertEquals("seed=$seed effective bar count", effective.size, stream.effective.size)
        effective.forEachIndexed { i, bar ->
            val streamed = stream.effective[i]
            assertEquals("seed=$seed eff[$i].rawIndex", bar.rawIndex, streamed.rawIndex)
            assertEquals("seed=$seed eff[$i].lastRawIndex", bar.lastRawIndex, streamed.lastRawIndex)
            assertEquals("seed=$seed eff[$i].high", bar.high, streamed.high, 0.0)
            assertEquals("seed=$seed eff[$i].low", bar.low, streamed.low, 0.0)
        }

        assertEquals("seed=$seed swing count", swings.size, stream.swings.size)
        swings.forEachIndexed { i, swing ->
            val streamed = stream.swings[i]
            assertEquals("seed=$seed swing[$i].type", swing.type, streamed.type)
            assertEquals("seed=$seed swing[$i].rawIndex", swing.rawIndex, streamed.rawIndex)
            assertEquals("seed=$seed swing[$i].price", swing.price, streamed.price, 0.0)
            assertEquals(
                "seed=$seed swing[$i].confirmationIndex",
                swing.confirmationIndex, streamed.confirmationIndex,
            )
        }

        assertEquals("seed=$seed event count", batchStructure.events.size, stream.events.size)
        batchStructure.events.forEachIndexed { i, event ->
            val streamed = stream.events[i]
            assertEquals("seed=$seed event[$i].type", event.type, streamed.type)
            assertEquals("seed=$seed event[$i].direction", event.direction, streamed.direction)
            assertEquals("seed=$seed event[$i].level", event.level, streamed.level, 0.0)
            assertEquals("seed=$seed event[$i].rawIndex", event.rawIndex, streamed.rawIndex)
        }

        assertEquals("seed=$seed fvg count", batchFvgs.size, stream.fvgs.size)
        batchFvgs.forEachIndexed { i, gap ->
            val streamed = stream.fvgs[i]
            assertEquals("seed=$seed fvg[$i].side", gap.side, streamed.side)
            assertEquals("seed=$seed fvg[$i].top", gap.top, streamed.top, 0.0)
            assertEquals("seed=$seed fvg[$i].bottom", gap.bottom, streamed.bottom, 0.0)
            assertEquals(
                "seed=$seed fvg[$i].confirmationEffIndex",
                gap.confirmationEffIndex, streamed.confirmationEffIndex,
            )
        }

        assertEquals("seed=$seed scob count", batchScobs.size, stream.scobs.size)
        batchScobs.forEachIndexed { i, scob ->
            val streamed = stream.scobs[i]
            assertEquals("seed=$seed scob[$i].direction", scob.direction, streamed.direction)
            assertEquals("seed=$seed scob[$i].effIndex", scob.effIndex, streamed.effIndex)
        }

        val streamedBlocks = stream.orderBlocks()
        assertEquals("seed=$seed order block count", batchBlocks.size, streamedBlocks.size)
        batchBlocks.forEachIndexed { i, block ->
            val streamed = streamedBlocks[i]
            assertEquals("seed=$seed ob[$i].direction", block.direction, streamed.direction)
            assertEquals("seed=$seed ob[$i].effIndex", block.effIndex, streamed.effIndex)
            assertEquals("seed=$seed ob[$i].shifted", block.shifted, streamed.shifted)
            assertEquals("seed=$seed ob[$i].top", block.top, streamed.top, 0.0)
            assertEquals("seed=$seed ob[$i].bottom", block.bottom, streamed.bottom, 0.0)
        }
    }

    @Test fun `streaming matches batch on seed 5`() = assertParity(5)
    @Test fun `streaming matches batch on seed 19`() = assertParity(19)
    @Test fun `streaming matches batch on seed 31`() = assertParity(31)
    @Test fun `streaming matches batch on seed 47`() = assertParity(47)
    @Test fun `streaming matches batch on seed 88`() = assertParity(88)

    @Test
    fun `order blocks contain no duplicate zones`() {
        val candles = series(1500, seed = 5)
        val effective = pullbacks.buildEffective(candles)
        val blocks = poi.findOrderBlocks(effective, poi.findFvgs(effective))

        val zones = blocks.map { it.direction to it.effIndex }
        assertEquals(
            "the same candle must not appear as several order blocks — " +
                "duplicate zones inflate the POI list and waste every freshness scan",
            zones.size,
            zones.toSet().size,
        )
        assertTrue("the fixture must actually produce blocks", blocks.isNotEmpty())
    }

    @Test
    fun `per-bar state snapshots align with the effective series`() {
        val candles = series(1200, seed = 47)
        val stream = streamEngine.replay(candles)
        assertEquals(
            "grading indexes states by effective-bar index; a short list means " +
                "silently null targets and zero signals",
            stream.effective.size,
            stream.states.size,
        )
        // majorHigh/majorLow change on SWING CONFIRMATION, which emits no event.
        // Storing state only at events therefore loses the target. Assert that
        // at least one bar carries structure levels no event ever announced.
        val eventBars = stream.events.map { it.effIndex }.toSet()
        val levelledNonEventBars = stream.states.withIndex().count { (i, st) ->
            i !in eventBars && (st.majorHigh != null || st.majorLow != null)
        }
        assertTrue(
            "state must be tracked between events, not only at them",
            levelledNonEventBars > 0,
        )
    }

    @Test
    fun `pushing bars one at a time never rewrites an emitted event`() {
        val candles = series(1200, seed = 31)
        val stream = streamEngine.open()

        val snapshots = ArrayList<List<LitStructureEvent>>()
        candles.forEach { candle ->
            stream.push(candle)
            snapshots += stream.events.toList()
        }

        // Every snapshot must be a prefix of the one after it.
        for (i in 1 until snapshots.size) {
            val before = snapshots[i - 1]
            val after = snapshots[i]
            assertTrue("events may only be appended", after.size >= before.size)
            before.forEachIndexed { j, event ->
                assertEquals("event[$j] type is immutable", event.type, after[j].type)
                assertEquals("event[$j] level is immutable", event.level, after[j].level, 0.0)
                assertEquals("event[$j] rawIndex is immutable", event.rawIndex, after[j].rawIndex)
            }
        }
    }
}
