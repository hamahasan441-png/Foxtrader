package com.foxtrader.app.domain.usecase.litadventure

import com.foxtrader.app.domain.model.Candle
import com.foxtrader.app.domain.model.StrategyType
import com.foxtrader.app.domain.model.Timeframe
import com.foxtrader.app.domain.usecase.AnalyzeMarketStructureUseCase
import com.foxtrader.app.domain.usecase.indicators.IchimokuCloud
import com.foxtrader.app.domain.usecase.litx.DisplacementDetector
import com.foxtrader.app.domain.usecase.litx.LitXConfidenceScorer
import com.foxtrader.app.domain.usecase.litx.LitXEngine
import com.foxtrader.app.domain.usecase.litx.MitigationBlockDetector
import com.foxtrader.app.domain.usecase.litx.MssClassifier
import com.foxtrader.app.domain.usecase.litx.PremiumDiscountCalculator
import com.foxtrader.app.domain.usecase.sessions.SessionDetector
import com.foxtrader.app.domain.usecase.smc.SmcDetector
import com.foxtrader.app.domain.usecase.strategies.StrategyLibrary
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/**
 * Proves LIT Adventure is actually reachable from the strategy registry — that
 * the package is registered, produces a usable definition, and honours the same
 * non-repainting contract as every other strategy.
 *
 * A feature that exists but is unreachable from the registry is not a feature.
 */
class LitAdventureWiringTest {

    private fun series(count: Int, seed: Int = 11): List<Candle> {
        val rng = Random(seed)
        var price = 1.1000
        var timestamp = 1_700_000_000_000L
        return (0 until count).map { i ->
            val drift = if ((i / 25) % 2 == 0) 0.00006 else -0.00006
            val open = price
            var high = open
            var low = open
            var close = open
            repeat(4) {
                close += drift + (rng.nextDouble() - 0.5) * 0.00024
                high = maxOf(high, close)
                low = minOf(low, close)
            }
            price = close
            timestamp += 300_000L
            Candle(timestamp, open, high, low, close, 100.0)
        }
    }

    private fun library() = StrategyLibrary(
        smcDetector = SmcDetector(),
        analyzeStructure = AnalyzeMarketStructureUseCase(),
        ichimokuCloud = IchimokuCloud(),
        litXEngine = LitXEngine(
            smcDetector = SmcDetector(),
            analyzeStructure = AnalyzeMarketStructureUseCase(),
            sessionDetector = SessionDetector(),
            displacementDetector = DisplacementDetector(),
            mitigationDetector = MitigationBlockDetector(),
            premiumDiscount = PremiumDiscountCalculator(),
            mssClassifier = MssClassifier(),
            scorer = LitXConfidenceScorer(),
        ),
    )

    @Test
    fun `LIT Adventure is registered in the strategy library`() {
        val all = library().all(symbol = "EURUSD", timeframe = Timeframe.M5)
        assertEquals(
            "every StrategyType must have a definition",
            StrategyType.entries.size,
            all.size,
        )
        val definition = all[StrategyType.LIT_ADVENTURE]
        assertNotNull("LIT Adventure package must resolve", definition)
        assertEquals("LIT Adventure Package", definition!!.name)
        assertTrue("needs enough bars for HTF grading", definition.minimumBars >= 100)
    }

    @Test
    fun `LIT Adventure strategy function runs across a series without throwing`() {
        val candles = series(400)
        val definition = library().get(StrategyType.LIT_ADVENTURE, "EURUSD", Timeframe.M5)
        var evaluated = 0
        for (i in candles.indices) {
            val signal = definition.function(candles.subList(0, i + 1), i)
            evaluated++
            if (signal != null) {
                assertEquals("a signal must belong to the bar it was evaluated on", i, signal.index)
                assertTrue("stop must differ from entry", signal.stopLoss != signal.entry)
            }
        }
        assertEquals(candles.size, evaluated)
    }

    @Test
    fun `signals are not repainted when later candles arrive`() {
        val candles = series(400, seed = 23)
        val definition = library().get(StrategyType.LIT_ADVENTURE, "EURUSD", Timeframe.M5)

        val cutoff = 300

        // Live: the app only ever has the bars up to "now".
        val truncated = candles.subList(0, cutoff)
        val liveSignals = truncated.indices.mapNotNull { i ->
            definition.function(truncated.subList(0, i + 1), i)
        }

        // Replay: the same bars, but with 100 further candles sitting in the
        // same backing list. If any detector reached past its slice, the answers
        // would differ here.
        val replayed = (0 until cutoff).mapNotNull { i ->
            definition.function(candles.subList(0, i + 1), i)
        }

        assertEquals("signal count is stable", liveSignals.size, replayed.size)
        liveSignals.forEachIndexed { index, signal ->
            val later = replayed[index]
            assertEquals("index stable", signal.index, later.index)
            assertEquals("direction stable", signal.direction, later.direction)
            assertEquals("entry stable", signal.entry, later.entry, 1e-12)
            assertEquals("stop stable", signal.stopLoss, later.stopLoss, 1e-12)
        }
    }

    @Test
    fun `analyzer reports inside bar absorption and rejected liquidity grabs`() {
        val pullbacks = LitPullbackEngine()
        val structure = LitAdventureStructure()
        val analyzer = LitAdventureAnalyzer(
            pullbacks = pullbacks,
            structure = structure,
            poi = LitPoiDetector(),
            mastermap = LitMastermapEngine(pullbacks, structure),
            traps = SmartMoneyTrapDetector(),
        )

        val candles = series(400)
        val context = analyzer.analyse(candles)

        assertTrue("inside bars must be absorbed", context.effective.size < candles.size)
        assertTrue("notes explain what the engine did", context.notes.isNotEmpty())
        context.events.filter { it.type == LitStructureEventType.BOS }.forEach { bos ->
            assertTrue(
                "a BOS without a taken inducement is exactly what LIT forbids",
                context.events.any {
                    it.type == LitStructureEventType.IDM_SWEEP && it.effIndex <= bos.effIndex
                },
            )
        }
    }
}
