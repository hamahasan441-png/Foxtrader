package com.foxtrader.app.domain.usecase.litadventure

import com.foxtrader.app.domain.model.Candle
import com.foxtrader.app.domain.model.Direction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Cross-implementation parity test for the LIT Adventure engine.
 *
 * The expected values below come from an INDEPENDENT reference implementation of
 * the same rule set (a Python engine validated on synthetic random-walk data,
 * where it correctly returns expectancy near minus-costs -- the check that
 * proves it is not leaking future information).
 *
 * Two implementations of one spec that agree bar-for-bar is evidence the spec
 * was implemented. One implementation passing its own tests is not. If the
 * Kotlin port drifts, this fails and names the rule that drifted.
 *
 * Reference series: 200 bars, 175 effective (25 inside bars absorbed),
 * 19 swings, 44 structure events (3 BOS, 3 CHoCH, 4 IDM sweeps, 34 rejected
 * liquidity grabs).
 */
class LitAdventureParityTest {

    private val pullbacks = LitPullbackEngine()
    private val structure = LitAdventureStructure()

    private fun c(ts: Long, o: Double, h: Double, l: Double, cl: Double) =
        Candle(ts * 1000L, o, h, l, cl, 100.0)

    private fun s(kind: String, rawIndex: Int, price: Double, confirm: Int) =
        arrayOf<Any>(kind, rawIndex, price, confirm)

    private fun e(type: String, side: String, level: Double, rawIndex: Int) =
        arrayOf<Any>(type, side, level, rawIndex)

    private val candles: List<Candle> = listOf(
        c(1700000000L, 1.1, 1.10026, 1.1, 1.10012),
        c(1700000300L, 1.10012, 1.10034, 1.10012, 1.10034),
        c(1700000600L, 1.10034, 1.10056, 1.10021, 1.10056),
        c(1700000900L, 1.10056, 1.1009, 1.10056, 1.1009),
        c(1700001200L, 1.1009, 1.10142, 1.1009, 1.10142),
        c(1700001500L, 1.10142, 1.10174, 1.10142, 1.10161),
        c(1700001800L, 1.10161, 1.10165, 1.10147, 1.10147),
        c(1700002100L, 1.10147, 1.10171, 1.10143, 1.10143),
        c(1700002400L, 1.10143, 1.10158, 1.10136, 1.10158),
        c(1700002700L, 1.10158, 1.10237, 1.10158, 1.10226),
        c(1700003000L, 1.10226, 1.10238, 1.10214, 1.10238),
        c(1700003300L, 1.10238, 1.10285, 1.10238, 1.10285),
        c(1700003600L, 1.10285, 1.10312, 1.10285, 1.10301),
        c(1700003900L, 1.10301, 1.10378, 1.10301, 1.10378),
        c(1700004200L, 1.10378, 1.10378, 1.10363, 1.10363),
        c(1700004500L, 1.10363, 1.10363, 1.10343, 1.10363),
        c(1700004800L, 1.10363, 1.10392, 1.1035, 1.10392),
        c(1700005100L, 1.10392, 1.10442, 1.10392, 1.10437),
        c(1700005400L, 1.10437, 1.10452, 1.10427, 1.10452),
        c(1700005700L, 1.10452, 1.10452, 1.10437, 1.10452),
        c(1700006000L, 1.10452, 1.10472, 1.10451, 1.10468),
        c(1700006300L, 1.10468, 1.10468, 1.10421, 1.10421),
        c(1700006600L, 1.10421, 1.10475, 1.10417, 1.10475),
        c(1700006900L, 1.10475, 1.10486, 1.10463, 1.10463),
        c(1700007200L, 1.10463, 1.10501, 1.10463, 1.10501),
        c(1700007500L, 1.10501, 1.10501, 1.10483, 1.10499),
        c(1700007800L, 1.10499, 1.10499, 1.10461, 1.10461),
        c(1700008100L, 1.10461, 1.10461, 1.10413, 1.10413),
        c(1700008400L, 1.10413, 1.10413, 1.1038, 1.1038),
        c(1700008700L, 1.1038, 1.1038, 1.10333, 1.10333),
        c(1700009000L, 1.10333, 1.10358, 1.10333, 1.10341),
        c(1700009300L, 1.10341, 1.10341, 1.10288, 1.10288),
        c(1700009600L, 1.10288, 1.10288, 1.10263, 1.10265),
        c(1700009900L, 1.10265, 1.10265, 1.10227, 1.10227),
        c(1700010200L, 1.10227, 1.10265, 1.10227, 1.10239),
        c(1700010500L, 1.10239, 1.1024, 1.10228, 1.10228),
        c(1700010800L, 1.10228, 1.10235, 1.10179, 1.10179),
        c(1700011100L, 1.10179, 1.10179, 1.10152, 1.10154),
        c(1700011400L, 1.10154, 1.10154, 1.10097, 1.10097),
        c(1700011700L, 1.10097, 1.10108, 1.10076, 1.10076),
        c(1700012000L, 1.10076, 1.10076, 1.10018, 1.10018),
        c(1700012300L, 1.10018, 1.10018, 1.09993, 1.09993),
        c(1700012600L, 1.09993, 1.09999, 1.09972, 1.09972),
        c(1700012900L, 1.09972, 1.09972, 1.0994, 1.0994),
        c(1700013200L, 1.0994, 1.09949, 1.09927, 1.09932),
        c(1700013500L, 1.09932, 1.09932, 1.0992, 1.09932),
        c(1700013800L, 1.09932, 1.09932, 1.09903, 1.09903),
        c(1700014100L, 1.09903, 1.09903, 1.09871, 1.09881),
        c(1700014400L, 1.09881, 1.09899, 1.09881, 1.09899),
        c(1700014700L, 1.09899, 1.09908, 1.0988, 1.0988),
        c(1700015000L, 1.0988, 1.0988, 1.09857, 1.09857),
        c(1700015300L, 1.09857, 1.09883, 1.09857, 1.09877),
        c(1700015600L, 1.09877, 1.09918, 1.09877, 1.09906),
        c(1700015900L, 1.09906, 1.0995, 1.09906, 1.0995),
        c(1700016200L, 1.0995, 1.10004, 1.0995, 1.10004),
        c(1700016500L, 1.10004, 1.10039, 1.10004, 1.10039),
        c(1700016800L, 1.10039, 1.10059, 1.10034, 1.10059),
        c(1700017100L, 1.10059, 1.10081, 1.10059, 1.10079),
        c(1700017400L, 1.10079, 1.10111, 1.10076, 1.10111),
        c(1700017700L, 1.10111, 1.10175, 1.10111, 1.10175),
        c(1700018000L, 1.10175, 1.1018, 1.10166, 1.10175),
        c(1700018300L, 1.10175, 1.10213, 1.10175, 1.10213),
        c(1700018600L, 1.10213, 1.10219, 1.10206, 1.10208),
        c(1700018900L, 1.10208, 1.10233, 1.10203, 1.10233),
        c(1700019200L, 1.10233, 1.10264, 1.10233, 1.10262),
        c(1700019500L, 1.10262, 1.10292, 1.10262, 1.10277),
        c(1700019800L, 1.10277, 1.10294, 1.10268, 1.10294),
        c(1700020100L, 1.10294, 1.1034, 1.10294, 1.1034),
        c(1700020400L, 1.1034, 1.10374, 1.1034, 1.10355),
        c(1700020700L, 1.10355, 1.10407, 1.10355, 1.10407),
        c(1700021000L, 1.10407, 1.10449, 1.10407, 1.10448),
        c(1700021300L, 1.10448, 1.10466, 1.10448, 1.10465),
        c(1700021600L, 1.10465, 1.10497, 1.10465, 1.10497),
        c(1700021900L, 1.10497, 1.10523, 1.10497, 1.10523),
        c(1700022200L, 1.10523, 1.1053, 1.10519, 1.10524),
        c(1700022500L, 1.10524, 1.10524, 1.10493, 1.10493),
        c(1700022800L, 1.10493, 1.10511, 1.10493, 1.10497),
        c(1700023100L, 1.10497, 1.10524, 1.10497, 1.10505),
        c(1700023400L, 1.10505, 1.10514, 1.10497, 1.10504),
        c(1700023700L, 1.10504, 1.10504, 1.10477, 1.10477),
        c(1700024000L, 1.10477, 1.10477, 1.10434, 1.10434),
        c(1700024300L, 1.10434, 1.10434, 1.10412, 1.10412),
        c(1700024600L, 1.10412, 1.10435, 1.10412, 1.10415),
        c(1700024900L, 1.10415, 1.10457, 1.10415, 1.1044),
        c(1700025200L, 1.1044, 1.1044, 1.10395, 1.10395),
        c(1700025500L, 1.10395, 1.10407, 1.10344, 1.10344),
        c(1700025800L, 1.10344, 1.10344, 1.10288, 1.1029),
        c(1700026100L, 1.1029, 1.1029, 1.10244, 1.10244),
        c(1700026400L, 1.10244, 1.10255, 1.10228, 1.10228),
        c(1700026700L, 1.10228, 1.1024, 1.10216, 1.10222),
        c(1700027000L, 1.10222, 1.10222, 1.10187, 1.10187),
        c(1700027300L, 1.10187, 1.10187, 1.10152, 1.10152),
        c(1700027600L, 1.10152, 1.10157, 1.10117, 1.10117),
        c(1700027900L, 1.10117, 1.10126, 1.10111, 1.10117),
        c(1700028200L, 1.10117, 1.10117, 1.10088, 1.10088),
        c(1700028500L, 1.10088, 1.10096, 1.10077, 1.10077),
        c(1700028800L, 1.10077, 1.10077, 1.10042, 1.10067),
        c(1700029100L, 1.10067, 1.10067, 1.09992, 1.09992),
        c(1700029400L, 1.09992, 1.10023, 1.09992, 1.10001),
        c(1700029700L, 1.10001, 1.10001, 1.09969, 1.09969),
        c(1700030000L, 1.09969, 1.10014, 1.09969, 1.10003),
        c(1700030300L, 1.10003, 1.10028, 1.10003, 1.10015),
        c(1700030600L, 1.10015, 1.10031, 1.10015, 1.10026),
        c(1700030900L, 1.10026, 1.10066, 1.10026, 1.10062),
        c(1700031200L, 1.10062, 1.10072, 1.1006, 1.1006),
        c(1700031500L, 1.1006, 1.1011, 1.1006, 1.1011),
        c(1700031800L, 1.1011, 1.10163, 1.1011, 1.10161),
        c(1700032100L, 1.10161, 1.10226, 1.10161, 1.10226),
        c(1700032400L, 1.10226, 1.10259, 1.10226, 1.10259),
        c(1700032700L, 1.10259, 1.10274, 1.10255, 1.10273),
        c(1700033000L, 1.10273, 1.10334, 1.10273, 1.1033),
        c(1700033300L, 1.1033, 1.10393, 1.1033, 1.10393),
        c(1700033600L, 1.10393, 1.10434, 1.10393, 1.10434),
        c(1700033900L, 1.10434, 1.10442, 1.10426, 1.10439),
        c(1700034200L, 1.10439, 1.10457, 1.10425, 1.10457),
        c(1700034500L, 1.10457, 1.10488, 1.10457, 1.10473),
        c(1700034800L, 1.10473, 1.10505, 1.10473, 1.10502),
        c(1700035100L, 1.10502, 1.1056, 1.10502, 1.1056),
        c(1700035400L, 1.1056, 1.10608, 1.1056, 1.10608),
        c(1700035700L, 1.10608, 1.10647, 1.10608, 1.10647),
        c(1700036000L, 1.10647, 1.10673, 1.10647, 1.10673),
        c(1700036300L, 1.10673, 1.10699, 1.10673, 1.10699),
        c(1700036600L, 1.10699, 1.1074, 1.10693, 1.1074),
        c(1700036900L, 1.1074, 1.10811, 1.1074, 1.10811),
        c(1700037200L, 1.10811, 1.10846, 1.10811, 1.10846),
        c(1700037500L, 1.10846, 1.10846, 1.1082, 1.1082),
        c(1700037800L, 1.1082, 1.1082, 1.10766, 1.10766),
        c(1700038100L, 1.10766, 1.10801, 1.10766, 1.10801),
        c(1700038400L, 1.10801, 1.10801, 1.10756, 1.10756),
        c(1700038700L, 1.10756, 1.10756, 1.10725, 1.10732),
        c(1700039000L, 1.10732, 1.10732, 1.10716, 1.10718),
        c(1700039300L, 1.10718, 1.10739, 1.10718, 1.10731),
        c(1700039600L, 1.10731, 1.10731, 1.10712, 1.10712),
        c(1700039900L, 1.10712, 1.10712, 1.10671, 1.10671),
        c(1700040200L, 1.10671, 1.1069, 1.10671, 1.10686),
        c(1700040500L, 1.10686, 1.10689, 1.10647, 1.10647),
        c(1700040800L, 1.10647, 1.10677, 1.1064, 1.1067),
        c(1700041100L, 1.1067, 1.1067, 1.10633, 1.10633),
        c(1700041400L, 1.10633, 1.10633, 1.10609, 1.10609),
        c(1700041700L, 1.10609, 1.10615, 1.10603, 1.10603),
        c(1700042000L, 1.10603, 1.10603, 1.10562, 1.10562),
        c(1700042300L, 1.10562, 1.10562, 1.1051, 1.1052),
        c(1700042600L, 1.1052, 1.1052, 1.10451, 1.10451),
        c(1700042900L, 1.10451, 1.10451, 1.10409, 1.10419),
        c(1700043200L, 1.10419, 1.10422, 1.10392, 1.10392),
        c(1700043500L, 1.10392, 1.10407, 1.10386, 1.10386),
        c(1700043800L, 1.10386, 1.10396, 1.10375, 1.10396),
        c(1700044100L, 1.10396, 1.10408, 1.10374, 1.10374),
        c(1700044400L, 1.10374, 1.10374, 1.10352, 1.10365),
        c(1700044700L, 1.10365, 1.10365, 1.10314, 1.10314),
        c(1700045000L, 1.10314, 1.10323, 1.10306, 1.10306),
        c(1700045300L, 1.10306, 1.10351, 1.10306, 1.10351),
        c(1700045600L, 1.10351, 1.10365, 1.10349, 1.10349),
        c(1700045900L, 1.10349, 1.10409, 1.10349, 1.10409),
        c(1700046200L, 1.10409, 1.10442, 1.10409, 1.10442),
        c(1700046500L, 1.10442, 1.10467, 1.10442, 1.10467),
        c(1700046800L, 1.10467, 1.10499, 1.10467, 1.10499),
        c(1700047100L, 1.10499, 1.10518, 1.10499, 1.10518),
        c(1700047400L, 1.10518, 1.10541, 1.10518, 1.10541),
        c(1700047700L, 1.10541, 1.10574, 1.10529, 1.10574),
        c(1700048000L, 1.10574, 1.10612, 1.10574, 1.10612),
        c(1700048300L, 1.10612, 1.10638, 1.10612, 1.10638),
        c(1700048600L, 1.10638, 1.10678, 1.10638, 1.10678),
        c(1700048900L, 1.10678, 1.10678, 1.10646, 1.10646),
        c(1700049200L, 1.10646, 1.10661, 1.10646, 1.10657),
        c(1700049500L, 1.10657, 1.10708, 1.10657, 1.10703),
        c(1700049800L, 1.10703, 1.1075, 1.10703, 1.1075),
        c(1700050100L, 1.1075, 1.10762, 1.1075, 1.10762),
        c(1700050400L, 1.10762, 1.10774, 1.10755, 1.10757),
        c(1700050700L, 1.10757, 1.10817, 1.10757, 1.10817),
        c(1700051000L, 1.10817, 1.10824, 1.10808, 1.10815),
        c(1700051300L, 1.10815, 1.10819, 1.10797, 1.10817),
        c(1700051600L, 1.10817, 1.10845, 1.10817, 1.10841),
        c(1700051900L, 1.10841, 1.10845, 1.10825, 1.10845),
        c(1700052200L, 1.10845, 1.10897, 1.10845, 1.10897),
        c(1700052500L, 1.10897, 1.10897, 1.10859, 1.10859),
        c(1700052800L, 1.10859, 1.10859, 1.10808, 1.10808),
        c(1700053100L, 1.10808, 1.10808, 1.10771, 1.10771),
        c(1700053400L, 1.10771, 1.10777, 1.10744, 1.10744),
        c(1700053700L, 1.10744, 1.10744, 1.10714, 1.10715),
        c(1700054000L, 1.10715, 1.10715, 1.10674, 1.10674),
        c(1700054300L, 1.10674, 1.10679, 1.10655, 1.10655),
        c(1700054600L, 1.10655, 1.10664, 1.10654, 1.10664),
        c(1700054900L, 1.10664, 1.10664, 1.10641, 1.10641),
        c(1700055200L, 1.10641, 1.1066, 1.10638, 1.10642),
        c(1700055500L, 1.10642, 1.10659, 1.10594, 1.10597),
        c(1700055800L, 1.10597, 1.10633, 1.10589, 1.10631),
        c(1700056100L, 1.10631, 1.10631, 1.10614, 1.10615),
        c(1700056400L, 1.10615, 1.1062, 1.10597, 1.10607),
        c(1700056700L, 1.10607, 1.10608, 1.106, 1.106),
        c(1700057000L, 1.106, 1.10611, 1.1057, 1.1057),
        c(1700057300L, 1.1057, 1.10573, 1.1054, 1.1054),
        c(1700057600L, 1.1054, 1.10547, 1.10511, 1.10511),
        c(1700057900L, 1.10511, 1.10511, 1.10484, 1.10492),
        c(1700058200L, 1.10492, 1.10511, 1.10488, 1.10488),
        c(1700058500L, 1.10488, 1.1049, 1.10477, 1.1049),
        c(1700058800L, 1.1049, 1.1049, 1.10436, 1.1044),
        c(1700059100L, 1.1044, 1.1044, 1.10418, 1.10437),
        c(1700059400L, 1.10437, 1.10437, 1.10395, 1.10395),
        c(1700059700L, 1.10395, 1.10395, 1.10331, 1.10331),
    )

    /** Raw indices surviving inside-bar absorption. */
    private val expectedEffective = intArrayOf(0, 1, 2, 3, 4, 5, 8, 9, 10, 11, 12, 13, 16, 17, 18, 20, 21, 22, 23, 24, 26, 27, 28, 29, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 129, 130, 131, 132, 133, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 165, 166, 167, 168, 169, 170, 171, 172, 174, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 190, 191, 192, 193, 195, 196, 197, 198, 199)

    /** kind, rawIndex, price, confirmationIndex */
    private val expectedSwings = listOf(
        s("high", 5, 1.10174, 8),
        s("low", 8, 1.10136, 9),
        s("high", 20, 1.10472, 21),
        s("low", 21, 1.10421, 22),
        s("high", 24, 1.10501, 26),
        s("low", 47, 1.09871, 49),
        s("high", 49, 1.09908, 50),
        s("low", 50, 1.09857, 51),
        s("high", 74, 1.1053, 75),
        s("low", 81, 1.10412, 82),
        s("high", 83, 1.10457, 84),
        s("low", 99, 1.09969, 100),
        s("high", 124, 1.10846, 126),
        s("low", 130, 1.10716, 131),
        s("high", 131, 1.10739, 132),
        s("low", 150, 1.10306, 151),
        s("high", 170, 1.10824, 171),
        s("low", 171, 1.10797, 172),
        s("high", 174, 1.10897, 176),
    )

    /** type, direction, level, rawIndex */
    private val expectedEvents = listOf(
        e("CHOCH", "bull", 1.10174, 9),
        e("SWEEP", "bull", 1.10174, 10),
        e("SWEEP", "bull", 1.10238, 11),
        e("SWEEP", "bull", 1.10285, 12),
        e("SWEEP", "bull", 1.10312, 13),
        e("SWEEP", "bull", 1.10378, 16),
        e("SWEEP", "bull", 1.10392, 17),
        e("SWEEP", "bull", 1.10442, 18),
        e("SWEEP", "bull", 1.10452, 20),
        e("IDM_SWEEP", "bull", 1.10421, 22),
        e("BOS", "bull", 1.10472, 22),
        e("SWEEP", "bull", 1.10475, 24),
        e("CHOCH", "bear", 1.10417, 27),
        e("SWEEP", "bear", 1.10417, 28),
        e("SWEEP", "bear", 1.1038, 29),
        e("SWEEP", "bear", 1.10333, 31),
        e("SWEEP", "bear", 1.10288, 32),
        e("SWEEP", "bear", 1.10263, 33),
        e("SWEEP", "bear", 1.10227, 36),
        e("SWEEP", "bear", 1.10179, 37),
        e("SWEEP", "bear", 1.10152, 38),
        e("SWEEP", "bear", 1.10097, 39),
        e("SWEEP", "bear", 1.10076, 40),
        e("SWEEP", "bear", 1.10018, 41),
        e("SWEEP", "bear", 1.09993, 42),
        e("SWEEP", "bear", 1.09972, 43),
        e("SWEEP", "bear", 1.0994, 44),
        e("SWEEP", "bear", 1.09927, 46),
        e("SWEEP", "bear", 1.09903, 47),
        e("SWEEP", "bear", 1.09871, 50),
        e("IDM_SWEEP", "bear", 1.09908, 52),
        e("CHOCH", "bull", 1.10501, 73),
        e("SWEEP", "bull", 1.10501, 74),
        e("IDM_SWEEP", "bull", 1.10412, 84),
        e("BOS", "bull", 1.1053, 117),
        e("SWEEP", "bull", 1.1056, 118),
        e("SWEEP", "bull", 1.10608, 119),
        e("SWEEP", "bull", 1.10647, 120),
        e("SWEEP", "bull", 1.10673, 121),
        e("SWEEP", "bull", 1.10699, 122),
        e("SWEEP", "bull", 1.1074, 123),
        e("SWEEP", "bull", 1.10811, 124),
        e("IDM_SWEEP", "bull", 1.10716, 132),
        e("BOS", "bull", 1.10846, 174),
    )

    @Test
    fun `inside bar absorption matches reference`() {
        val effective = pullbacks.buildEffective(candles)
        assertEquals("effective bar count", expectedEffective.size, effective.size)
        effective.forEachIndexed { index, bar ->
            assertEquals("effective[$index].rawIndex", expectedEffective[index], bar.rawIndex)
        }
    }

    @Test
    fun `correct pullback swings match reference`() {
        val effective = pullbacks.buildEffective(candles)
        val swings = pullbacks.detectSwings(effective)
        assertEquals("swing count", expectedSwings.size, swings.size)
        swings.forEachIndexed { index, swing ->
            val expected = expectedSwings[index]
            assertEquals("swing[$index].type", expected[0] as String, swing.type.name.lowercase())
            assertEquals("swing[$index].rawIndex", expected[1] as Int, swing.rawIndex)
            assertEquals("swing[$index].price", expected[2] as Double, swing.price, 1e-9)
            assertEquals("swing[$index].confirmationIndex", expected[3] as Int, swing.confirmationIndex)
        }
    }

    @Test
    fun `structure events match reference`() {
        val effective = pullbacks.buildEffective(candles)
        val swings = pullbacks.detectSwings(effective)
        val result = structure.run(effective, swings, LitAdventureConfig(idmMode = LitIdmMode.FIRST))

        assertEquals("event count", expectedEvents.size, result.events.size)
        result.events.forEachIndexed { index, event ->
            val expected = expectedEvents[index]
            assertEquals("event[$index].type", expected[0] as String, event.type.name)
            val side = if (event.direction == Direction.BULLISH) "bull" else "bear"
            assertEquals("event[$index].direction", expected[1] as String, side)
            assertEquals("event[$index].level", expected[2] as Double, event.level, 1e-9)
            assertEquals("event[$index].rawIndex", expected[3] as Int, event.rawIndex)
        }
    }

    @Test
    fun `a break with an untaken inducement is a sweep and never a BOS`() {
        val effective = pullbacks.buildEffective(candles)
        val swings = pullbacks.detectSwings(effective)
        val result = structure.run(effective, swings)

        val sweeps = result.events.count { it.type == LitStructureEventType.SWEEP }
        assertTrue(
            "the reference series contains liquidity grabs a naive engine would label BOS",
            sweeps > 0,
        )
        result.events.filter { it.type == LitStructureEventType.BOS }.forEach { bos ->
            val inducementTaken = result.events.any {
                it.type == LitStructureEventType.IDM_SWEEP && it.effIndex <= bos.effIndex
            }
            assertTrue("every BOS is preceded by a taken inducement", inducementTaken)
        }
    }

    @Test
    fun `appending candles never mutates an already confirmed event`() {
        val prefix = candles.take(candles.size - 20)

        val prefixEffective = pullbacks.buildEffective(prefix)
        val prefixEvents = structure.run(prefixEffective, pullbacks.detectSwings(prefixEffective)).events

        val fullEffective = pullbacks.buildEffective(candles)
        val fullEvents = structure.run(fullEffective, pullbacks.detectSwings(fullEffective)).events

        assertTrue("prefix cannot produce more events than the full series", prefixEvents.size <= fullEvents.size)
        prefixEvents.forEachIndexed { index, event ->
            val later = fullEvents[index]
            assertEquals("event[$index] type is stable", event.type, later.type)
            assertEquals("event[$index] level is stable", event.level, later.level, 1e-12)
            assertEquals("event[$index] rawIndex is stable", event.rawIndex, later.rawIndex)
        }
    }

    @Test
    fun `both idm modes stay internally consistent`() {
        // FIRST vs LAST is a research decision, not a default. On large samples
        // the two differ by more than 10x in trade count; on this short series
        // they may agree. What must ALWAYS hold is the invariant.
        val effective = pullbacks.buildEffective(candles)
        val swings = pullbacks.detectSwings(effective)
        listOf(LitIdmMode.FIRST, LitIdmMode.LAST).forEach { mode ->
            val result = structure.run(effective, swings, LitAdventureConfig(idmMode = mode))
            result.events.filter { it.type == LitStructureEventType.BOS }.forEach { bos ->
                assertTrue(
                    "mode=$mode: BOS without a preceding inducement",
                    result.events.any {
                        it.type == LitStructureEventType.IDM_SWEEP && it.effIndex <= bos.effIndex
                    },
                )
            }
        }
    }

    @Test
    fun `effective series never widens a mother bar`() {
        val effective = pullbacks.buildEffective(candles)
        effective.forEach { bar ->
            val source = candles[bar.rawIndex]
            assertEquals("mother high preserved", source.high, bar.high, 1e-12)
            assertEquals("mother low preserved", source.low, bar.low, 1e-12)
        }
    }
}
