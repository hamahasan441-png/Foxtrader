package com.foxtrader.app.feature.chart.presentation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.StackedLineChart
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.foxtrader.app.R
import com.foxtrader.app.domain.model.Bias
import com.foxtrader.app.domain.model.ChartSignal
import com.foxtrader.app.domain.model.ChartBarMode
import com.foxtrader.app.domain.model.ConnectionState
import com.foxtrader.app.domain.model.DataProvider
import com.foxtrader.app.domain.model.EquityPoint
import com.foxtrader.app.domain.model.MarketDataFreshness
import com.foxtrader.app.domain.model.StrategyType
import com.foxtrader.app.domain.model.StrategyBlueprint
import com.foxtrader.app.domain.model.Timeframe
import com.foxtrader.app.ui.theme.FoxWarning
import com.foxtrader.app.feature.chart.presentation.components.CandleChart
import com.foxtrader.app.feature.chart.presentation.components.ChartAnalysisSheet
import com.foxtrader.app.feature.chart.presentation.components.ChartOhlcLegend
import com.foxtrader.app.feature.chart.presentation.components.DrawingManagerDialog
import com.foxtrader.app.feature.chart.presentation.components.DrawingPalette
import com.foxtrader.app.feature.chart.presentation.components.IndicatorPanel
import com.foxtrader.app.feature.chart.presentation.components.MultiChartSection
import com.foxtrader.app.feature.chart.presentation.components.MultiChartToolbar
import com.foxtrader.app.feature.chart.presentation.components.ChartPaneStack
import com.foxtrader.app.feature.chart.presentation.components.ReplayControlBar
import com.foxtrader.app.feature.calculator.presentation.PositionCalculatorSheet
import com.foxtrader.app.feature.chart.presentation.components.SymbolPickerDialog
import com.foxtrader.app.ui.theme.FoxAmber50
import com.foxtrader.app.ui.theme.FoxBearishText
import com.foxtrader.app.ui.theme.FoxBullishText
import com.foxtrader.app.ui.theme.FoxError
import com.foxtrader.app.ui.theme.FoxNeutral60
import com.foxtrader.app.ui.theme.FoxSuccess

/**
 * The Chart screen — the heart of FoxTrader.
 *
 * Integrates:
 * - Professional candlestick chart with all overlays
 * - Interactive timeframe selector
 * - Drawing tools toolbar
 * - Replay mode controls
 * - Connection state indicator
 * - Pull-to-refresh
 * - Debug render-performance HUD (debug builds only)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChartScreen(
    modifier: Modifier = Modifier,
    onNavigateToAlerts: () -> Unit = {},
    onNavigateToTradeManagement: () -> Unit = {},
    onNavigateToStudio: () -> Unit = {},
    onNavigateToLitX: (String, Timeframe) -> Unit = { _, _ -> },
    immersive: Boolean = false,
    onToggleImmersive: () -> Unit = {},
    viewModel: ChartViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val multiChartState by viewModel.multiChartState.collectAsStateWithLifecycle()
    val replayState by viewModel.replayState.collectAsStateWithLifecycle()
    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val unreadAlerts by viewModel.unreadAlertCount.collectAsStateWithLifecycle()

    // --- Render performance instrumentation (drives adaptive quality only) ---
    // The monitor still runs to feed the adaptive-quality controller, but the
    // on-chart FPS/frame-budget HUD has been removed — it is not user-facing.
    val monitor = viewModel.performanceMonitor
    val view = LocalView.current

    DisposableEffect(view) {
        // Profile against the *actual* refresh rate of this display: a 120 Hz
        // panel has an 8.33 ms budget, a 60 Hz panel 16.67 ms. Using a fixed
        // target would either under-report jank or over-degrade quality.
        val refreshHz = view.display?.refreshRate?.toInt()?.coerceAtLeast(60) ?: 60
        monitor.start(refreshHz)
        onDispose {
            monitor.stop()
        }
    }

    // --- Track which dropdown menu is open (only one at a time) ---
    var activeMenu by remember { mutableStateOf(ChartMenu.NONE) }

    // --- Per-object drawing manager sheet (list-based delete) ---
    var showDrawingManager by remember { mutableStateOf(false) }

    // --- Bottom "Analysis" sheet expand/collapse (R2) ---
    // Consolidates the AI decision, market context, MTF confluence and TRADEPRO
    // setup that previously floated over the price action into one on-demand
    // sheet, keeping the canvas clean (TradingView-style).
    var analysisExpanded by remember { mutableStateOf(false) }

    // --- Price-scale lock (R7): freezes the Y auto-fit during pan/zoom ---
    var scaleLocked by remember { mutableStateOf(false) }

    // The candle series shown right now (replay bars while replaying, else the
    // live series), as a stable CandleSeries. Shared by the main chart and the
    // volume pane so their bar indices stay aligned (R3/R5).
    val displayCandles = remember(replayState.isActive, replayState.visibleCandles, state.candles) {
        (if (replayState.isActive) replayState.visibleCandles else state.candles).asCandleSeries()
    }

    // Keep the default price canvas clean: current/live confirmations remain
    // visible, while historical strategy markers appear only when the trader
    // explicitly enables Signal History from the chart toolbar.
    val visibleSignals = remember(state.signals, state.showSignalHistory) {
        if (state.showSignalHistory) state.signals else state.signals.filter { it.isLive }
    }

    val visibleBacktestMarkers = remember(
        state.chartBacktest.markers, state.chartBacktest.showMarkers, replayState.isActive,
    ) {
        // Never expose completed-trade outcomes while replaying historical bars;
        // doing so would leak future information into the replay session.
        if (state.chartBacktest.showMarkers && !replayState.isActive) state.chartBacktest.markers else emptyList()
    }

    // `INSETS` The app-level Scaffold in FoxNavHost already applies the system-bar
    // window insets (status bar on top, navigation bar on the bottom) to the
    // NavHost that hosts this screen. The previous manual `padding(top = 24.dp)`
    // was therefore redundant double-padding that stole ~24dp from the chart and
    // rendered incorrectly on cutout/notch devices. It is intentionally removed
    // so the chart reclaims that space and honours real insets.
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        // --- Top bar (hidden in immersive/full-screen focus mode, R1) ---
        if (!immersive) {
            ChartTopBar(
                state = state,
                connectionState = connectionState,
                unreadAlerts = unreadAlerts,
                onAlertsClick = onNavigateToAlerts,
                onCalculatorClick = viewModel::openCalculator,
                onSymbolClick = viewModel::openSymbolPicker,
                onProviderChange = viewModel::onDataProviderChange,
                onLiveToggle = viewModel::toggleLive,
                onToggleAnalysis = { analysisExpanded = !analysisExpanded },
            )
        }

        // --- Synthetic-data warning ---
        // Kept visible even in immersive mode: it is a safety-critical notice
        // that the chart is rendering generated (not real) prices.
        SyntheticDataBanner(visible = state.isSyntheticData)

        // --- Compact Chart Toolbar (TradingView-style, hidden in immersive) ---
        if (!immersive) {
            ChartToolbar(
                activeMenu = activeMenu,
                currentTimeframe = state.timeframe,
                currentBarMode = state.barMode,
                // Single source of truth (R4): the Draw chip lights up when a tool
                // is actually armed, not from a duplicated showDrawingToolbar flag.
                showDrawingActive = state.activeTool != null,
                onMenuToggle = { menu ->
                    activeMenu = if (activeMenu == menu) ChartMenu.NONE else menu
                },
                onReplayStart = { viewModel.startReplay() },
                onToggleFullscreen = onToggleImmersive,
                scaleLocked = scaleLocked,
                onToggleScaleLock = { scaleLocked = !scaleLocked },
                signalsActive = state.showSignalHistory,
                onSignalsToggle = viewModel::toggleSignalHistory,
                onOpenStudio = onNavigateToStudio,
            )
        }

        // --- Expandable panels (only one visible at a time) ---
        // Timeframe dropdown
        AnimatedVisibility(
            visible = !immersive && activeMenu == ChartMenu.TIMEFRAME,
            enter = expandVertically(),
            exit = shrinkVertically(),
        ) {
            TimeframeDropdown(
                selected = state.timeframe,
                onSelect = { tf ->
                    viewModel.onTimeframeChange(tf)
                    activeMenu = ChartMenu.NONE
                },
            )
        }

        // Bar-mode dropdown
        AnimatedVisibility(
            visible = !immersive && activeMenu == ChartMenu.BAR_MODE,
            enter = expandVertically(),
            exit = shrinkVertically(),
        ) {
            BarModeDropdown(
                selected = state.barMode,
                onSelect = { mode ->
                    viewModel.onBarModeChange(mode)
                    activeMenu = ChartMenu.NONE
                },
            )
        }

        // Indicators dropdown
        AnimatedVisibility(
            visible = !immersive && activeMenu == ChartMenu.INDICATORS,
            enter = expandVertically(),
            exit = shrinkVertically(),
        ) {
            IndicatorPanel(
                visible = true,
                toggles = state.indicators,
                strategyBlueprints = state.strategyBlueprints,
                onToggle = viewModel::updateIndicators,
            )
        }

        // Backtest-on-chart dropdown
        AnimatedVisibility(
            visible = !immersive && activeMenu == ChartMenu.BACKTEST,
            enter = expandVertically(),
            exit = shrinkVertically(),
        ) {
            ChartBacktestPanel(
                state = state.chartBacktest,
                blueprints = state.strategyBlueprints,
                currentBarCount = state.candles.size,
                currentNewestTimestamp = state.candles.lastOrNull()?.timestamp,
                currentBarMode = state.barMode,
                dataIsSynthetic = state.isSyntheticData,
                onStrategySelect = viewModel::selectChartBacktestStrategy,
                onRangeSelect = viewModel::selectChartBacktestRange,
                onBlueprintSelect = viewModel::selectChartBacktestBlueprint,
                onRun = viewModel::runChartBacktest,
                onClear = viewModel::clearChartBacktest,
                onToggleMarkers = viewModel::toggleChartBacktestMarkers,
            )
        }

        // NOTE (R4): drawing tools are no longer an inline dropdown that pushes
        // the chart down. They are a floating, auto-hiding DrawingPalette rail
        // rendered as an overlay inside the chart Box below.

        // Multi-chart dropdown
        AnimatedVisibility(
            visible = !immersive && activeMenu == ChartMenu.MULTI_CHART,
            enter = expandVertically(),
            exit = shrinkVertically(),
        ) {
            MultiChartToolbar(
                layout = multiChartState.layout,
                linkedToPrimary = multiChartState.linkedToPrimary,
                symbolLinkEnabled = multiChartState.symbolLinkEnabled,
                timeframeLinkEnabled = multiChartState.timeframeLinkEnabled,
                crosshairSyncEnabled = multiChartState.crosshairSyncEnabled,
                canAddPanel = multiChartState.panels.size < 4,
                onLayoutChange = viewModel::setMultiChartLayout,
                onToggleLinking = viewModel::toggleMultiChartLinking,
                onToggleSymbolLink = viewModel::toggleMultiChartSymbolLink,
                onToggleTimeframeLink = viewModel::toggleMultiChartTimeframeLink,
                onToggleCrosshairSync = viewModel::toggleMultiChartCrosshairSync,
                onAddPanel = viewModel::addMultiChartPanel,
            )
        }

        // --- Symbol picker dialog ---
        SymbolPickerDialog(
            visible = state.showSymbolPicker,
            symbols = state.availableSymbols,
            selected = state.symbol,
            onSelect = viewModel::onSymbolChange,
            onDismiss = viewModel::closeSymbolPicker,
            onAddSymbol = viewModel::addSymbolToWatchlist,
            onRemoveSymbol = viewModel::removeSymbolFromWatchlist,
        )

        if (state.showCalculator) {
            PositionCalculatorSheet(
                symbol = state.symbol,
                lastPrice = state.lastPrice,
                onDismiss = viewModel::closeCalculator,
            )
        }

        // --- Chart area with pull-to-refresh ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
        ) {
            PullToRefreshBox(
                isRefreshing = state.isLoading,
                onRefresh = viewModel::refresh,
                modifier = Modifier.fillMaxSize(),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center,
                ) {
                    when {
                        state.hasData -> Box(Modifier.fillMaxSize()) {
                            CandleChart(
                            // `PERF` Stable CandleSeries so Compose can skip the
                            // chart when inputs are unchanged (R5). Shared with the
                            // volume pane for index alignment (R3).
                            candles = displayCandles,
                            modifier = Modifier.fillMaxSize(),
                            structureBreaks = state.structureBreaks,
                            timeframe = state.timeframe,
                            seriesKey = "${state.symbol}:${state.timeframe.label}",
                            initialViewportState = viewModel.currentPrimaryViewportState(),
                            onViewportStateChange = viewModel::onPrimaryViewportStateChange,
                            emaShort = state.emaShort,
                            emaLong = state.emaLong,
                            bollingerUpper = state.bollingerUpper,
                            bollingerMiddle = state.bollingerMiddle,
                            bollingerLower = state.bollingerLower,
                            superTrendValues = state.superTrendValues,
                            superTrendDir = state.superTrendDir,
                            parabolicSar = state.parabolicSar,
                            vwap = state.vwap,
                            anchoredVwap = state.anchoredVwap,
                            anchoredVwapUpper = state.anchoredVwapUpper,
                            anchoredVwapLower = state.anchoredVwapLower,
                            ichimokuTenkan = state.ichimokuTenkan,
                            ichimokuKijun = state.ichimokuKijun,
                            ichimokuSenkouA = state.ichimokuSenkouA,
                            ichimokuSenkouB = state.ichimokuSenkouB,
                            ichimokuChikou = state.ichimokuChikou,
                            keltnerUpper = state.keltnerUpper,
                            keltnerMiddle = state.keltnerMiddle,
                            keltnerLower = state.keltnerLower,
                            donchianUpper = state.donchianUpper,
                            donchianMiddle = state.donchianMiddle,
                            donchianLower = state.donchianLower,
                            pivotLevels = state.pivotLevels,
                            orderBlocks = state.orderBlocks,
                            fairValueGaps = state.fairValueGaps,
                            liquidityPools = state.liquidityPools,
                            tradeProAnalysis = state.tradeProAnalysis,
                            litXAnalysis = state.litXAnalysis,
                            smtDivergences = state.smtDivergences,
                            signals = visibleSignals,
                            backtestMarkers = visibleBacktestMarkers,
                            indicators = state.indicators,
                            sessions = state.sessions,
                            drawings = state.drawings,
                            volumeProfile = state.volumeProfile,
                            marketProfile = state.marketProfile,
                            supportResistanceZones = state.supportResistanceZones,
                            autoFibLevels = state.autoFibLevels,
                            autoFibDirection = state.autoFibDirection,
                            autoFibSwingHigh = state.autoFibSwingHigh,
                            autoFibSwingLow = state.autoFibSwingLow,
                            canLoadOlder = !state.historyEndReached && !replayState.isActive,
                            isLoadingOlder = state.isLoadingOlder && !replayState.isActive,
                            onLoadOlder = viewModel::loadOlderHistory,
                            syncedCrosshairTimestamp = state.syncedCrosshairTimestamp,
                            onCrosshairTimestampChange = viewModel::onPrimaryCrosshairTimestampChange,
                            performanceMonitor = monitor,
                            autoScaleEnabled = !scaleLocked,
                            chartContentDescription = stringResource(
                                R.string.chart_canvas_cd,
                                state.symbol,
                                state.timeframe.label,
                            ),
                        )
                        ChartOhlcLegend(
                            candle = displayCandles.lastOrNull(),
                            previousCandle = displayCandles.getOrNull(displayCandles.lastIndex - 1),
                            freshness = state.dataFreshness,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp),
                        )
                        if (!replayState.isActive && state.showSignalHistory && state.liveSignalStats.totalObserved > 0) {
                            com.foxtrader.app.feature.chart.presentation.components.LiveSignalPerformanceOverlay(
                                stats = state.liveSignalStats,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 8.dp, end = 70.dp),
                            )
                        }
                        if (!replayState.isActive) {
                            ChartBacktestSummaryOverlay(
                                state = state.chartBacktest,
                                currentBarCount = state.candles.size,
                                currentNewestTimestamp = state.candles.lastOrNull()?.timestamp,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 44.dp, end = 70.dp),
                            )
                        }
                        }
                        state.isLoading -> CircularProgressIndicator(color = FoxAmber50)
                        state.error != null -> Text(
                            text = state.error ?: "",
                            color = FoxBearishText,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        else -> Text(
                            text = stringResource(R.string.chart_no_data),
                            color = FoxNeutral60,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }

            // NOTE (R2): the AI decision, market context, MTF confluence and
            // TRADEPRO setup cards no longer float over the price action. They
            // are consolidated into the collapsible ChartAnalysisSheet anchored
            // at the bottom of this Box, so the canvas stays clean and the
            // detail is available on demand (TradingView-style).

            // --- Exit full-screen button (only in immersive focus mode, R1) ---
            // The chrome + bottom nav are hidden in immersive mode, so this is
            // the way back out. Top-end keeps it clear of the bottom overlays.
            if (immersive) {
                SmallFloatingActionButton(
                    onClick = onToggleImmersive,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = FoxAmber50,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 8.dp, end = 8.dp),
                ) {
                    Icon(
                        Icons.Default.FullscreenExit,
                        contentDescription = stringResource(R.string.chart_focus_exit),
                    )
                }
            }

            // --- Floating drawing tool palette (left edge, auto-hiding, R4) ---
            DrawingPalette(
                visible = activeMenu == ChartMenu.DRAWING,
                activeTool = state.activeTool,
                onToolSelect = viewModel::startDrawing,
                onClearAll = viewModel::clearAllDrawings,
                onManage = { showDrawingManager = true },
                onClose = { activeMenu = ChartMenu.NONE },
                modifier = Modifier.align(Alignment.CenterStart),
            )

            // --- Per-object drawing manager (list-based delete) ---
            if (showDrawingManager) {
                DrawingManagerDialog(
                    drawings = state.drawings,
                    onDelete = viewModel::deleteDrawing,
                    onDismiss = { showDrawingManager = false },
                )
            }

            // --- Replay control bar (bottom overlay) ---
            ReplayControlBar(
                state = replayState,
                onPlayPause = viewModel::toggleReplayPlayPause,
                onStepForward = viewModel::replayStepForward,
                onStepBackward = viewModel::replayStepBackward,
                onCycleSpeed = viewModel::replayCycleSpeed,
                onClose = viewModel::stopReplay,
                modifier = Modifier.align(Alignment.BottomCenter),
            )

            // --- Executable setup actions ---
            if (state.tradeProAnalysis?.setup?.isExecutable == true) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 12.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.End,
                ) {
                    SmallFloatingActionButton(
                        onClick = onNavigateToTradeManagement,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    ) {
                        Icon(
                            Icons.Default.TrendingUp,
                            contentDescription = stringResource(R.string.chart_open_trade_management),
                        )
                    }
                }
            }

            // --- Consolidated Analysis sheet (bottom overlay, R2) ---
            // Hidden during replay so it never fights the replay control bar,
            // which also anchors to the bottom-centre.
            if (!replayState.isActive) {
                // Signal history panel (toggleable, above the analysis sheet).
                // Extracted into a scope-free helper so overload resolution binds
                // to the top-level AnimatedVisibility rather than the ColumnScope
                // overload leaking in from the outer Column.
                SignalHistoryOverlay(
                    visible = state.showSignalHistory,
                    signals = state.signals,
                    modifier = Modifier.align(Alignment.BottomCenter),
                )

                ChartAnalysisSheet(
                    expanded = analysisExpanded,
                    onToggleExpanded = { analysisExpanded = !analysisExpanded },
                    bias = state.bias,
                    decision = state.aiDecision,
                    explanation = state.marketExplanation,
                    confluence = if (state.indicators.confluence) state.confluence else null,
                    tradeProAnalysis = state.tradeProAnalysis,
                    phase13Fusion = state.signalFusion,
                    modifier = Modifier.align(Alignment.BottomCenter),
                )
            }
        }

        // --- Separate-pane indicators (RSI / MACD / Volume) below the chart ---
        // Resizable pane stack (R3). Collects the reactive viewport internally so
        // panes track main-chart pan/zoom without recomposing the chart itself.
        if (state.hasData && !immersive) {
            ChartPaneStack(
                indicators = state.indicators,
                candles = displayCandles,
                rsiValues = state.rsiValues,
                macdLine = state.macdLine,
                macdSignal = state.macdSignal,
                macdHistogram = state.macdHistogram,
                stochasticK = state.stochasticK,
                stochasticD = state.stochasticD,
                obv = state.obv,
                moneyFlowIndex = state.moneyFlowIndex,
                viewportFlow = viewModel.primaryViewport,
                fallbackViewport = viewModel.currentPrimaryViewportState(),
            )
        }

        MultiChartSection(
            state = multiChartState,
            availableSymbols = state.availableSymbols,
            primarySymbol = state.symbol,
            primaryTimeframe = state.timeframe,
            onPanelActivate = viewModel::setActiveMultiChartPanel,
            onSetPanelSymbol = viewModel::setMultiChartPanelSymbol,
            onSetPanelTimeframe = viewModel::setMultiChartPanelTimeframe,
            onResetPanelToPrimary = viewModel::resetMultiChartPanelToPrimary,
            onMovePanel = viewModel::moveMultiChartPanelToIndex,
            onRemovePanel = viewModel::removeMultiChartPanel,
            onPanelCrosshairTimestampChange = viewModel::onMultiChartPanelCrosshairTimestampChange,
            onPanelViewportStateChange = viewModel::onMultiChartPanelViewportStateChange,
            panelViewportState = viewModel::currentMultiChartPanelViewportState,
        )
    }
}

/**
 * Toggleable signal-history overlay.
 *
 * Extracted into its own composable that carries no layout-scope receiver so the
 * `AnimatedVisibility` call binds unambiguously to the top-level overload. Calling
 * it inline inside the chart's [androidx.compose.foundation.layout.Box] (which is
 * itself nested in a [androidx.compose.foundation.layout.Column]) made both the
 * `BoxScope` and `ColumnScope` `AnimatedVisibility` overloads candidates, and the
 * compiler bound to the `ColumnScope` one via the outer receiver — which is illegal
 * across the `Box` boundary. The caller supplies the alignment modifier.
 */
@Composable
private fun SignalHistoryOverlay(
    visible: Boolean,
    signals: List<ChartSignal>,
    modifier: Modifier = Modifier,
) {
    AnimatedVisibility(
        visible = visible,
        enter = expandVertically(),
        exit = shrinkVertically(),
        modifier = modifier,
    ) {
        ChartSignalHistory(
            signals = signals,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun ChartTopBar(
    state: ChartUiState,
    connectionState: ConnectionState,
    unreadAlerts: Int,
    onAlertsClick: () -> Unit,
    onCalculatorClick: () -> Unit,
    onSymbolClick: () -> Unit,
    onProviderChange: (DataProvider) -> Unit,
    onLiveToggle: () -> Unit,
    onToggleAnalysis: () -> Unit,
) {
    var providerMenuExpanded by remember { mutableStateOf(false) }
    val currentSymbolDescription = stringResource(R.string.chart_current_symbol_cd, state.symbol)
    val live = connectionState == ConnectionState.CONNECTED &&
        state.dataFreshness == MarketDataFreshness.LIVE
    val delayed = state.dataFreshness == MarketDataFreshness.DELAYED
    val cached = state.dataFreshness == MarketDataFreshness.CACHED
    val liveError = connectionState == ConnectionState.ERROR ||
        connectionState == ConnectionState.AUTH_FAILED || connectionState == ConnectionState.FATAL
    val liveLabel = when {
        !state.liveAvailable && !state.liveEnabled -> stringResource(R.string.chart_live_unavailable)
        live -> stringResource(R.string.chart_live_connected)
        delayed -> stringResource(R.string.chart_data_delayed)
        cached && state.liveEnabled -> stringResource(R.string.chart_data_cached)
        liveError -> stringResource(R.string.chart_live_error)
        state.liveEnabled -> stringResource(R.string.chart_live_connecting)
        else -> stringResource(R.string.chart_live_off)
    }
    val liveStateDescription = when {
        !state.liveAvailable && !state.liveEnabled -> stringResource(R.string.chart_live_unavailable_state)
        live -> stringResource(R.string.chart_live_connected_state)
        delayed -> stringResource(R.string.chart_data_delayed_state)
        cached -> stringResource(R.string.chart_data_cached_state)
        liveError -> stringResource(R.string.chart_live_error_state)
        else -> stringResource(R.string.chart_live_disconnected_state)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(
                horizontal = ChartDimens.topBarHorizontalPadding,
                vertical = ChartDimens.topBarVerticalPadding,
            ),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            text = stringResource(R.string.chart_brand_short),
            color = FoxAmber50,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
        )
        Text(
            text = state.symbol,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(MaterialTheme.colorScheme.primaryContainer)
                .clickable(
                    onClickLabel = stringResource(R.string.chart_top_symbol_picker_label),
                    role = Role.Button,
                    onClick = onSymbolClick,
                )
                .padding(horizontal = 10.dp, vertical = 5.dp)
                .semantics { contentDescription = currentSymbolDescription },
        )
        Box {
            Text(
                text = providerShortLabel(state.dataProvider),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable(role = Role.Button) { providerMenuExpanded = true }
                    .padding(horizontal = 7.dp, vertical = 4.dp),
            )
            DropdownMenu(
                expanded = providerMenuExpanded,
                onDismissRequest = { providerMenuExpanded = false },
            ) {
                providerGroups().forEach { (group, providers) ->
                    Text(
                        text = group,
                        style = MaterialTheme.typography.labelSmall,
                        color = FoxNeutral60,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                    )
                    providers.forEach { provider ->
                        DropdownMenuItem(
                            text = { Text(provider.displayName) },
                            onClick = {
                                providerMenuExpanded = false
                                onProviderChange(provider)
                            },
                            enabled = provider != state.dataProvider,
                        )
                    }
                }
            }
        }
        BiasBadge(state.bias)
        Text(
            text = liveLabel,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (live || liveError) MaterialTheme.colorScheme.background else FoxNeutral60,
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(
                    when {
                        live -> FoxSuccess
                        delayed -> FoxWarning
                        liveError -> FoxError
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                )
                .clickable(
                    enabled = state.liveAvailable || state.liveEnabled,
                    onClickLabel = if (state.liveEnabled) {
                        stringResource(R.string.chart_disconnect_live_feed)
                    } else {
                        stringResource(R.string.chart_connect_live_feed)
                    },
                    onClick = onLiveToggle,
                )
                .padding(horizontal = 6.dp, vertical = 3.dp)
                .semantics {
                    role = Role.Switch
                    stateDescription = liveStateDescription
                },
        )

        Spacer(Modifier.weight(1f))

        IconButton(onClick = onCalculatorClick, modifier = Modifier.size(32.dp)) {
            Icon(
                Icons.Default.Calculate,
                contentDescription = stringResource(R.string.chart_open_position_size_calculator),
                tint = FoxNeutral60,
                modifier = Modifier.size(18.dp),
            )
        }
        IconButton(onClick = onToggleAnalysis, modifier = Modifier.size(32.dp)) {
            Icon(
                Icons.Default.Insights,
                contentDescription = stringResource(R.string.chart_insights),
                tint = FoxAmber50,
                modifier = Modifier.size(18.dp),
            )
        }
        AlertsBellButton(unreadCount = unreadAlerts, onClick = onAlertsClick)

        state.lastPrice?.let { price ->
            val formattedPrice = formatPrice(price)
            val priceDescription = stringResource(R.string.chart_current_price_cd, formattedPrice)
            Text(
                text = formattedPrice,
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.semantics {
                    contentDescription = priceDescription
                },
            )
        }
    }
}

/**
 * Enum for which dropdown menu is currently expanded.
 * Only one menu can be open at a time (TradingView behavior).
 */
private fun providerShortLabel(provider: DataProvider): String = provider.displayName

/** Group the native Deriv source separately from general market feeds. */
private fun providerGroups(): List<Pair<String, List<DataProvider>>> {
    val implemented = DataProvider.implemented()
    return listOf(
        "DERIV" to implemented.filter { it == DataProvider.DERIV },
        "OTHER DATA PROVIDERS" to implemented.filter { it != DataProvider.DERIV },
    ).filter { it.second.isNotEmpty() }
}

private enum class ChartMenu {
    NONE, TIMEFRAME, BAR_MODE, INDICATORS, BACKTEST, DRAWING, MULTI_CHART
}

/**
 * Compact chart toolbar — TradingView-style.
 * A single slim row of icon buttons; tapping one toggles its dropdown panel.
 */
@Composable
private fun ChartToolbar(
    activeMenu: ChartMenu,
    currentTimeframe: Timeframe,
    currentBarMode: ChartBarMode,
    showDrawingActive: Boolean,
    onMenuToggle: (ChartMenu) -> Unit,
    onReplayStart: () -> Unit,
    onToggleFullscreen: () -> Unit,
    scaleLocked: Boolean,
    onToggleScaleLock: () -> Unit,
    signalsActive: Boolean,
    onSignalsToggle: () -> Unit,
    onOpenStudio: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(
                horizontal = ChartDimens.toolbarHorizontalPadding,
                vertical = ChartDimens.toolbarVerticalPadding,
            ),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        // Timeframe button - shows current TF label
        ToolbarChipButton(
            label = currentTimeframe.label,
            icon = Icons.Default.Timer,
            isActive = activeMenu == ChartMenu.TIMEFRAME,
            onClick = { onMenuToggle(ChartMenu.TIMEFRAME) },
            contentDescription = stringResource(R.string.chart_timeframe_selector_cd),
        )

        // Bar-mode button - shows current mode label
        ToolbarChipButton(
            label = currentBarMode.label,
            icon = Icons.Default.ShowChart,
            isActive = activeMenu == ChartMenu.BAR_MODE,
            onClick = { onMenuToggle(ChartMenu.BAR_MODE) },
        )

        // Indicators button
        ToolbarChipButton(
            label = "Indicators",
            icon = Icons.Default.ShowChart,
            isActive = activeMenu == ChartMenu.INDICATORS,
            onClick = { onMenuToggle(ChartMenu.INDICATORS) },
        )

        // Drawing tools button
        ToolbarChipButton(
            label = "Draw",
            icon = Icons.Default.Edit,
            isActive = activeMenu == ChartMenu.DRAWING || showDrawingActive,
            onClick = { onMenuToggle(ChartMenu.DRAWING) },
        )

        // Multi-chart button
        ToolbarChipButton(
            label = "Layout",
            icon = Icons.Default.Dashboard,
            isActive = activeMenu == ChartMenu.MULTI_CHART,
            onClick = { onMenuToggle(ChartMenu.MULTI_CHART) },
        )

        Spacer(Modifier.weight(1f))

        IconButton(
            onClick = onOpenStudio,
            modifier = Modifier.size(32.dp),
        ) {
            Icon(
                Icons.Default.Tune,
                contentDescription = "Open Pro Studio",
                tint = FoxNeutral60,
                modifier = Modifier.size(18.dp),
            )
        }

        // Replay button (no dropdown, direct action)
        IconButton(
            onClick = onReplayStart,
            modifier = Modifier.size(32.dp),
        ) {
            Icon(
                Icons.Default.Refresh,
                contentDescription = stringResource(R.string.chart_start_replay_mode),
                tint = FoxNeutral60,
                modifier = Modifier.size(18.dp),
            )
        }

        // Signals history toggle
        IconButton(
            onClick = onSignalsToggle,
            modifier = Modifier.size(32.dp),
        ) {
            Icon(
                Icons.Default.StackedLineChart,
                contentDescription = "Toggle signal history",
                tint = if (signalsActive) FoxAmber50 else FoxNeutral60,
                modifier = Modifier.size(18.dp),
            )
        }

        // On-chart backtest controls
        IconButton(
            onClick = { onMenuToggle(ChartMenu.BACKTEST) },
            modifier = Modifier.size(32.dp),
        ) {
            Icon(
                Icons.Default.TrendingUp,
                contentDescription = "Backtest on chart",
                tint = if (activeMenu == ChartMenu.BACKTEST) FoxAmber50 else FoxNeutral60,
                modifier = Modifier.size(18.dp),
            )
        }

        // Lock / unlock the price scale (R7).
        IconButton(
            onClick = onToggleScaleLock,
            modifier = Modifier.size(32.dp),
        ) {
            Icon(
                if (scaleLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                contentDescription = stringResource(R.string.chart_scale_toggle_lock),
                tint = if (scaleLocked) FoxAmber50 else FoxNeutral60,
                modifier = Modifier.size(18.dp),
            )
        }

        // Enter full-screen focus mode (R1) — hides the chrome + bottom nav.
        IconButton(
            onClick = onToggleFullscreen,
            modifier = Modifier.size(32.dp),
        ) {
            Icon(
                Icons.Default.Fullscreen,
                contentDescription = stringResource(R.string.chart_focus_enter),
                tint = FoxNeutral60,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

/**
 * Small chip-style button for the toolbar.
 */
@Composable
private fun ToolbarChipButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    onClick: () -> Unit,
    contentDescription: String? = null,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(
                if (isActive) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceVariant
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .then(
                if (contentDescription != null) {
                    Modifier.semantics { this.contentDescription = contentDescription }
                } else Modifier
            ),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = if (isActive) FoxAmber50 else FoxNeutral60,
            modifier = Modifier.size(14.dp),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
            color = if (isActive) FoxAmber50 else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Icon(
            Icons.Default.KeyboardArrowDown,
            contentDescription = null,
            tint = if (isActive) FoxAmber50 else FoxNeutral60,
            modifier = Modifier.size(12.dp),
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ChartBacktestPanel(
    state: ChartBacktestState,
    blueprints: List<StrategyBlueprint>,
    currentBarCount: Int,
    currentNewestTimestamp: Long?,
    currentBarMode: ChartBarMode,
    dataIsSynthetic: Boolean,
    onStrategySelect: (StrategyType) -> Unit,
    onRangeSelect: (ChartBacktestRange) -> Unit,
    onBlueprintSelect: (String) -> Unit,
    onRun: () -> Unit,
    onClear: () -> Unit,
    onToggleMarkers: () -> Unit,
) {
    val isStale = state.hasResult && (
        state.sourceBarsAtRun != currentBarCount ||
            (currentNewestTimestamp != null && state.sourceNewestTimestampAtRun != currentNewestTimestamp)
        )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column {
                Text(
                    "Backtest on Chart",
                    color = FoxAmber50,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelLarge,
                )
                Text(
                    "Same non-repainting strategy logic as live signals",
                    color = FoxNeutral60,
                    fontSize = 10.sp,
                )
            }
            if (state.isRunning) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        }

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            StrategyType.entries.forEach { strategy ->
                val selected = strategy == state.selectedStrategy && state.selectedBlueprintId == null
                Text(
                    text = strategy.label,
                    color = if (selected) FoxAmber50 else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (selected) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .clickable(enabled = !state.isRunning) { onStrategySelect(strategy) }
                        .padding(horizontal = 9.dp, vertical = 6.dp),
                )
            }
        }

        Text("History range", color = FoxNeutral60, fontSize = 9.sp)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            ChartBacktestRange.entries.forEach { range ->
                val selected = state.selectedRange == range
                Text(
                    text = range.label,
                    color = if (selected) FoxAmber50 else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (selected) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .clickable(enabled = !state.isRunning) { onRangeSelect(range) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                )
            }
        }

        if (blueprints.isNotEmpty()) {
            Text("Custom strategies", color = FoxNeutral60, fontSize = 9.sp)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                blueprints.forEach { blueprint ->
                    val selected = state.selectedBlueprintId == blueprint.id
                    Text(
                        text = blueprint.name,
                        color = if (selected) FoxAmber50 else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (selected) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .clickable(enabled = !state.isRunning) { onBlueprintSelect(blueprint.id) }
                            .padding(horizontal = 9.dp, vertical = 6.dp),
                    )
                }
            }
        }

        if (dataIsSynthetic) {
            Text(
                "Real market data is required. Simulated bars are never accepted for backtest results.",
                color = FoxWarning,
                fontSize = 10.sp,
            )
        }
        if (currentBarMode != ChartBarMode.TIME) {
            Text(
                "Switch bar mode to Time for executable-price backtesting.",
                color = FoxWarning,
                fontSize = 10.sp,
            )
        }
        state.error?.let { error ->
            Text(error, color = FoxBearishText, fontSize = 10.sp)
        }
        state.historyNotice?.let { notice ->
            Text(notice, color = FoxWarning, fontSize = 9.sp)
        }

        if (state.hasResult) {
            Text(
                "${state.strategyName}: ${state.totalSignals} signals • W ${state.winningSignals} • L ${state.losingSignals} • B ${state.breakevenSignals} • ${String.format(java.util.Locale.US, "%.1f", state.winRate)}% win rate • ${state.testedBars} closed bars${if (isStale) " • rerun for new bars" else ""}",
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                "PF ${String.format(java.util.Locale.US, "%.2f", state.profitFactor)} • Return ${String.format(java.util.Locale.US, "%.2f", state.returnPercent)}% • Max DD ${String.format(java.util.Locale.US, "%.2f", state.maxDrawdownPercent)}% • Exp ${String.format(java.util.Locale.US, "%.2f", state.expectancy)} • Avg R ${String.format(java.util.Locale.US, "%.2f", state.averageR)}",
                color = FoxNeutral60,
                fontSize = 9.sp,
            )
            BacktestEquitySparkline(state = state)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(
                onClick = onRun,
                enabled = !state.isRunning && !dataIsSynthetic && currentBarMode == ChartBarMode.TIME,
                colors = ButtonDefaults.buttonColors(containerColor = FoxAmber50),
                modifier = Modifier.weight(1f),
            ) {
                Text(if (state.isRunning) "Running…" else "Run Backtest", fontSize = 11.sp)
            }
            Text(
                if (state.showMarkers) "Markers ON" else "Markers OFF",
                color = if (state.showMarkers) FoxBullishText else FoxNeutral60,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable(enabled = state.markers.isNotEmpty()) { onToggleMarkers() }
                    .padding(horizontal = 10.dp, vertical = 9.dp),
            )
            Text(
                "Clear",
                color = FoxNeutral60,
                fontSize = 10.sp,
                modifier = Modifier
                    .clickable(enabled = state.hasResult || state.error != null) { onClear() }
                    .padding(8.dp),
            )
        }
    }
}

@Composable
private fun BacktestEquitySparkline(state: ChartBacktestState) {
    if (state.equityCurve.size < 2) return
    val points = remember(state.equityCurve) {
        val step = (state.equityCurve.size / 180).coerceAtLeast(1)
        buildList<EquityPoint> {
            var i = 0
            while (i < state.equityCurve.size) {
                add(state.equityCurve[i])
                i += step
            }
            val last = state.equityCurve.last()
            if (lastOrNull()?.timestamp != last.timestamp) add(last)
        }
    }
    val minBalance = points.minOf { it.balance }
    val maxBalance = points.maxOf { it.balance }
    val range = (maxBalance - minBalance).takeIf { it > 0.0 } ?: 1.0
    val lineColor = if (state.netPnL >= 0.0) FoxBullishText else FoxBearishText

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(42.dp),
    ) {
        val lastIndex = (points.size - 1).coerceAtLeast(1)
        for (i in 1 until points.size) {
            val prev = points[i - 1]
            val cur = points[i]
            val x1 = size.width * ((i - 1).toFloat() / lastIndex.toFloat())
            val x2 = size.width * (i.toFloat() / lastIndex.toFloat())
            val y1 = size.height - (((prev.balance - minBalance) / range).toFloat() * size.height)
            val y2 = size.height - (((cur.balance - minBalance) / range).toFloat() * size.height)
            drawLine(lineColor, Offset(x1, y1), Offset(x2, y2), strokeWidth = 2f)
        }
    }
}

@Composable
private fun ChartBacktestSummaryOverlay(
    state: ChartBacktestState,
    currentBarCount: Int,
    currentNewestTimestamp: Long?,
    modifier: Modifier = Modifier,
) {
    if (!state.hasResult) return
    val isStale = state.sourceBarsAtRun != currentBarCount ||
        (currentNewestTimestamp != null && state.sourceNewestTimestampAtRun != currentNewestTimestamp)
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.90f))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.End,
    ) {
        Text(
            text = "BT ${state.strategyName ?: state.selectedStrategy.label} • ${state.selectedRange.label}${if (!state.rangeCoverageComplete) "*" else ""}",
            color = FoxAmber50,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = "${state.totalSignals}  W ${state.winningSignals}  L ${state.losingSignals}  B ${state.breakevenSignals}",
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = "WR ${String.format(java.util.Locale.US, "%.1f", state.winRate)}%  P/L ${String.format(java.util.Locale.US, "%.0f", state.netPnL)}",
            color = if (state.netPnL >= 0.0) FoxBullishText else FoxBearishText,
            fontSize = 9.sp,
        )
        if (!state.rangeCoverageComplete) {
            Text("PARTIAL RANGE", color = FoxWarning, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
        if (isStale) {
            Text("NEW BARS — RERUN", color = FoxWarning, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/**
 * Timeframe dropdown panel - a compact flow of timeframe chips.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TimeframeDropdown(
    selected: Timeframe,
    onSelect: (Timeframe) -> Unit,
) {
    FlowRow(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Timeframe.entries.forEach { tf ->
            val isSelected = tf == selected
            Text(
                text = tf.label,
                color = if (isSelected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (isSelected) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .clickable { onSelect(tf) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
    }
}

/**
 * Bar-mode dropdown panel - a compact row of bar-mode chips.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BarModeDropdown(
    selected: ChartBarMode,
    onSelect: (ChartBarMode) -> Unit,
) {
    FlowRow(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        ChartBarMode.entries.forEach { mode ->
            val isSelected = mode == selected
            Text(
                text = mode.label,
                color = if (isSelected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (isSelected) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .clickable { onSelect(mode) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
    }
}

/**
 * Persistent warning shown whenever the chart is rendering generated bars.
 *
 * Deliberately NOT dismissible: the whole failure mode this guards against is a
 * trader forgetting that the provider was unreachable and reading a fabricated
 * random walk as their broker's price feed. It stays until real data arrives.
 */
/** Alerts entry point with an unread-count badge overlaid on the bell. */
@Composable
private fun AlertsBellButton(unreadCount: Int, onClick: () -> Unit) {
    Box {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = if (unreadCount > 0) {
                    stringResource(R.string.chart_alerts_inbox_with_unread, unreadCount)
                } else {
                    stringResource(R.string.chart_alerts_inbox)
                },
                tint = if (unreadCount > 0) FoxAmber50 else FoxNeutral60,
            )
        }
        if (unreadCount > 0) {
            Text(
                text = if (unreadCount > 9) "9+" else unreadCount.toString(),
                color = MaterialTheme.colorScheme.background,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 4.dp, end = 2.dp)
                    .clip(CircleShape)
                    .background(FoxAmber50)
                    .padding(horizontal = 4.dp),
            )
        }
    }
}

@Composable
private fun SyntheticDataBanner(visible: Boolean) {
    if (!visible) return
    val simulatedWarningDescription = stringResource(R.string.chart_simulated_warning_cd)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(FoxWarning.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .semantics {
                contentDescription = simulatedWarningDescription
            },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = "Warning",
            tint = FoxWarning,
            modifier = Modifier.height(16.dp),
        )
        Column {
            Text(
                text = stringResource(R.string.chart_simulated_data_title),
                color = FoxWarning,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
            )
            Text(
                text = stringResource(R.string.chart_simulated_data_message),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp,
            )
        }
    }
}

@Composable
private fun BiasBadge(bias: Bias) {
    val (color, label) = when (bias) {
        Bias.BULLISH -> FoxBullishText to stringResource(R.string.chart_bias_bullish)
        Bias.BEARISH -> FoxBearishText to stringResource(R.string.chart_bias_bearish)
        Bias.NEUTRAL -> FoxNeutral60 to stringResource(R.string.chart_bias_neutral)
    }
    val biasDescription = stringResource(R.string.chart_bias_cd, label)

    Text(
        text = label,
        color = color,
        style = MaterialTheme.typography.labelSmall,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .semantics { contentDescription = biasDescription },
    )
}

private fun formatPrice(price: Double): String =
    if (price >= 1000) String.format("%,.2f", price) else String.format("%.5f", price)
