package com.foxtrader.app.feature.backtest.presentation

import androidx.compose.runtime.Immutable
import com.foxtrader.app.domain.model.BacktestResult
import com.foxtrader.app.domain.model.BinaryBacktestResult
import com.foxtrader.app.domain.model.Candle
import com.foxtrader.app.domain.model.DataProvider
import com.foxtrader.app.domain.model.StrategyBlueprint
import com.foxtrader.app.domain.model.Timeframe
import com.foxtrader.app.domain.usecase.backtest.BacktestAnalyticsReport
import kotlinx.collections.immutable.ImmutableList
import kotlinx.collections.immutable.persistentListOf

/** Strategy templates available in the Backtesting Lab. */
enum class BacktestStrategyTemplate(
    val displayName: String,
    val description: String,
) {
    RSI_MEAN_REVERSION(
        displayName = "RSI Mean Reversion",
        description = "Trades confirmed RSI exits from oversold/overbought with ATR-adaptive risk.",
    ),
    EMA_TREND_PULLBACK(
        displayName = "EMA Trend Pullback",
        description = "Trades pullbacks in the direction of a 20/50 moving-average trend.",
    ),
    ATR_BREAKOUT(
        displayName = "ATR Breakout",
        description = "Trades volatility expansion through the recent range.",
    ),
    TRADEPRO(
        displayName = "TRADEPRO",
        description = "Order-flow/auction: Flip-Zone bias, Buy/Sell-Hold pullback + confirmation, " +
            "structural stop, trend-filtered.",
    ),
    LITX(
        displayName = "LIT X Institutional",
        description = "Sweep → market shift (CHOCH/MSS) → POI retest, gated by an 11-factor score.",
    ),
    DERIV_BINARY_3M(
        displayName = "Deriv Binary 3m Precision",
        description = "M1 closed-bar EMA/ADX pullback-reclaim setup; enters next bar and settles after 3 minutes. Non-repainting and fixed-expiry backtestable.",
    ),
}

/** Immutable UI state for the Backtesting Lab screen. */
@Immutable
data class BacktestLabUiState(
    val symbol: String = "EURUSD",
    val timeframe: Timeframe = Timeframe.H1,
    val dataProvider: DataProvider = DataProvider.DUKASCOPY,
    val strategy: BacktestStrategyTemplate = BacktestStrategyTemplate.RSI_MEAN_REVERSION,
    /** Non-null when a saved visual-builder strategy is selected. */
    val selectedBlueprintId: String? = null,
    val strategyBlueprints: ImmutableList<StrategyBlueprint> = persistentListOf(),
    val initialBalance: Double = 100_000.0,
    val riskPercent: Double = 1.0,
    val aiScoringEnabled: Boolean = true,
    val binaryPayoutRatio: Double = 0.85,
    val binaryMinConfidence: Int = 72,
    val availableSymbols: ImmutableList<String> = DEFAULT_SYMBOLS,
    val isRunning: Boolean = false,
    val error: String? = null,
    val result: BacktestResult? = null,
    val binaryResult: BinaryBacktestResult? = null,
    val analyticsReport: BacktestAnalyticsReport? = null,
    val lastRunTime: Long = 0L,
    val replayCandles: ImmutableList<Candle> = persistentListOf(),
    val replayCursor: Int = 0,
    val replayPlaying: Boolean = false,
) {
    val hasResult: Boolean get() = result != null || binaryResult != null
    val hasReplayData: Boolean get() = hasResult && replayCandles.isNotEmpty()
    val replayProgress: Double get() = if (replayCandles.size <= 1) 0.0 else replayCursor.coerceIn(0, replayCandles.lastIndex).toDouble() / replayCandles.lastIndex.toDouble()
    val isBinary3m: Boolean get() = selectedBlueprintId == null && strategy == BacktestStrategyTemplate.DERIV_BINARY_3M
    val selectedBlueprint: StrategyBlueprint?
        get() = selectedBlueprintId?.let { id -> strategyBlueprints.firstOrNull { it.id == id } }

    val selectedStrategyName: String
        get() = selectedBlueprint?.name ?: strategy.displayName

    val selectedStrategyDescription: String
        get() {
            val base = selectedBlueprint?.summary() ?: strategy.description
            return if (isBinary3m) {
                base
            } else {
                "$base • Execution: closed-bar signal → next-bar-open market fill."
            }
        }

    companion object {
        val DEFAULT_SYMBOLS = persistentListOf(
            "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "XAUUSD",
            "BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "NAS100", "US500",
            "R_10", "R_25", "R_50", "R_75", "R_100",
        )
        val DERIV_BINARY_SYMBOLS = persistentListOf(
            "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD",
            "R_10", "R_25", "R_50", "R_75", "R_100",
        )
    }
}
