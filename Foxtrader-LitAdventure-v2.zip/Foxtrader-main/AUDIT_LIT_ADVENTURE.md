# FoxTrader — repository audit

**Scope:** 707 Kotlin files (~105k LOC), 42 Python files (backend), 98 TypeScript
reference files, 186 test classes / 1302 `@Test` methods.
**Date:** 2026-08-24
**Method:** static analysis, cross-implementation comparison against an
independently validated LIT reference engine, Python compile-check and test-suite
inspection. **The Android module was not compiled** — this container has a JRE
but no `javac`, no `kotlinc`, and no network for Gradle. Every build-related
finding below is therefore a *static* judgement and is marked as such.

---

## Headline

**This is not fake code.** You asked me to look for fabricated implementations
and I looked hard for them. What I found instead is a genuinely engineered
codebase: the backtester passes `candles.subList(0, i + 1)` to strategies and
freezes position size on the decision bar so tomorrow's open cannot leak into
risk sizing; synthetic candles are tagged `CandleSource.SYNTHETIC` and only
generated when the user explicitly selects the SAMPLE provider; tokens live in
`EncryptedSharedPreferences`; `usesCleartextTraffic="false"`; there are zero
`TODO(`, zero `GlobalScope`, and no unresolved internal imports.

The real problems are different, and more interesting: **the LIT implementation
is not the LIT framework.** It is competent generic Smart Money Concepts wearing
LIT's name. That is the gap worth your time.

---

## Findings by severity

### S1 — Build will almost certainly fail

| Item | Evidence |
|---|---|
| **AGP 8.5.2 with `compileSdk = 36` / `targetSdk = 36`** | `gradle/libs.versions.toml:8`, `app/build.gradle.kts:41,46` |

AGP 8.5 predates the Android 16 (API 36) platform. Compiling against a platform
newer than the plugin understands fails or produces undefined behaviour. Bump AGP
to **8.9.1+** (8.11.x preferred) and Gradle to a matching wrapper version, or drop
`compileSdk`/`targetSdk` to 34. Your CI (`.github/workflows/android.yml`) builds a
real APK on GitHub runners, so this is verifiable in one push — **do that before
anything else in this document**, because it gates everything.

Secondary: `composeCompiler = "1.5.15"` is declared in the version catalog while
the project uses Kotlin 2.0.20 with the `kotlin.compose` plugin, which supplies
its own compiler. The stale pin is at best dead config and at worst a conflict.

### S2 — LIT fidelity gaps (the core issue)

The engine claims LIT but implements generic SMC. Five specific divergences, each
verified against the Chapter 1 material and the public LIT rule set:

| # | LIT rule | What the repo does | Where |
|---|---|---|---|
| 1 | **Inside bars are ignored entirely.** Structure, OBs, FVGs and SCOB all build on the inside-bar-filtered series | No inside-bar handling exists anywhere. The only trace is an unused `allowInsideBarMother` flag | `SignalIntelligence.kt:49`; grep for `insideBar` returns one hit |
| 2 | **Correct pullbacks.** A leg flips when a candle updates the *previous* candle's extreme | N-left/N-right fractal pivots — a renderer heuristic, not the LIT definition | `LitProStructureDetector.detectSwings` |
| 3 | **IDM is a precondition.** A break with the inducement untaken is a liquidity grab, not a BOS | Any confirmed break becomes BOS/CHoCH, then `findInducement` searches backwards to annotate it. The dependency is inverted | `LitProStructureDetector.classifyBreaks` + `findInducement:200` |
| 4 | **LIT order block** = liquidity-taking candle + attached FVG, shifted forward until an imbalance exists | Classic "last opposite-colour candle", optionally the deepest one. No liquidity-take requirement, no FVG requirement, no forward shift | `LitProStructureDetector.selectPoi:233` |
| 5 | **Inducement grade** (minor/medium/major) from HTF structure; **intent** (reversal/continuation) | Absent. Every IDM is treated as equivalent | — |

On a 200-bar reference series, rule 3 alone reclassifies **34 of 44 structure
events** from "BOS/CHoCH" to "liquidity grab". That is not a tuning difference;
it is a different read of the market.

Rule 1 is not cosmetic either: ~12–20% of bars are inside bars on typical
intraday data, and removing them changes which swings exist at all.

### S2 — SMT means two different things and they are being conflated

`SmtDivergenceDetector` documents itself as *"SMT (Smart Money Technique)
divergence detector"* — correlated-instrument divergence, the ICT meaning. LIT
Adventure uses SMT for **Smart Money Trap**: a smart-money trader trapped by an
inducement, detectable on a single chart with no peer feed.

Both are legitimate techniques. The hazard is that they are summed into one
confluence score as if they were the same evidence, and that a UI label reading
"SMT" doesn't say which one it means. (I had this wrong in my own first spec
until the Chapter 1 material corrected me.)

### S3 — Two parallel LIT engines

`LitEngine` (signalintel) and `LitXEngine` (litx) are both injected into
`ChartViewModel`, `StrategyLibrary` and `StrategyPackageEngine`, and both appear
as separate strategy packages ("LIT Institutional Package", "LIT X Institutional
Package"). Two implementations of an ambiguous framework, maintained in parallel,
will drift — and there is no parity test between them, only within each.

Either make one canonical and the other a thin variant, or add a
`LitXVsLitEngineParityTest` that pins where they are *allowed* to differ.

### S3 — `runBlocking` inside an OkHttp interceptor

`AuthInterceptor.kt:149` calls `runBlocking { doRefresh(refreshToken) }`. It is on
an OkHttp dispatcher thread, not the main thread, so it will not ANR — but it
occupies a connection-pool thread for the full duration of a token refresh, and
under concurrent 401s can starve the pool. A single-flight mutex plus a
`CountDownLatch`, or moving refresh to an `Authenticator`, is the standard fix.

### S4 — Weaker, worth noting

- **Backend deps unpinned** (`fastapi>=0.115,<1.0`) — reproducible builds need a
  lockfile or exact pins.
- `MonteCarloRiskEngine` and `SampleData` both take an explicit seed — good, but
  confirm the seed is surfaced in any reported result, or two runs of the same
  "risk analysis" will disagree and neither will be reproducible.
- `reference/typescript-src` (98 files) ships in the repo with no build wiring.
  If it is a porting reference, move it out of the module or document it; dead
  weight in a repo becomes dead weight in a review.

---

## What is genuinely good

Worth saying plainly, because it changes what you should do next:

- **Backtester discipline.** No look-ahead by construction; explicit
  `SIGNAL_PRICE` vs `NEXT_BAR_OPEN` modes; size frozen on the decision bar; a
  gap-through-stop opens at the executable open rather than granting a price the
  market skipped; conservative SL-before-TP; user-strategy exceptions isolated per
  bar instead of aborting the run. This is better than most commercial backtesters.
- **Provenance honesty.** Synthetic data cannot masquerade as a real fetch —
  there is an explicit early return and a `CandleSource.SYNTHETIC` tag.
- **Non-repaint contracts** are stated and tested: `LitNoFutureMutationTest`,
  `LitLiveBacktestParityTest`, `LitProviderParityTest`, `SmtPrefixStabilityTest`.
- **Room schemas exported** to `app/schemas/` so migrations are testable.
- **CI builds a real APK** and the release workflow runs only on version tags.

---

## The fix, in order

1. **Unblock the build.** AGP → 8.9.1+, drop the stale `composeCompiler` pin,
   push, confirm the CI artifact installs. Nothing else is real until this is.
2. **Drop in `domain/usecase/litadventure/`** (provided alongside this document).
   Five files implementing the rules above, plus `LitAdventureParityTest` whose
   expected values come from the independent reference engine.
3. **Wire it as an additive path**, not a replacement: register
   `LitAdventureAnalyzer` as a new strategy package next to the existing two, and
   run all three over the same data. Compare. Let the backtest decide which
   survives — that is the only honest way to settle it.
4. **Split SMT.** Rename the existing detector to `SmtDivergenceDetector`
   throughout the UI copy ("Smart Money divergence"), and surface
   `SmartMoneyTrapDetector` separately as "Smart Money Trap". Never sum them.
5. **Settle `idmMode` empirically.** FIRST vs LAST changed trade count by more
   than 10x on the reference run (17 vs 252 trades, +1.24R vs −0.43R expectancy).
   This is the highest-leverage unknown in the entire framework and it is a
   research question, not a default.
6. **Route every LIT signal through the existing risk gate.** The paper-trading
   risk-engine bypass found in the earlier audit is exactly the failure mode a
   new signal source reintroduces.

---

## Honest limits of this audit

- **Nothing here was compiled.** No `javac`, no `kotlinc`, no Gradle network. The
  Kotlin I am handing you is carefully written but *compiler-unverified* — expect
  to fix import and signature details on first build. The Python reference engine
  it was ported from **is** executed and self-tested.
- The Python backend compiles cleanly (`py_compile` across all 42 files) but
  `pytest` is unavailable here, so its 17 test modules were read, not run.
- I did not review every one of the 707 Kotlin files line by line. I mapped the
  architecture, then went deep on the paths that matter for your stated goal:
  signal generation, LIT, SMT, backtesting, data provenance, and security.
- **On "best APK in the world":** the engineering here is already strong. What
  will decide whether this app is good is not more features — it is whether the
  LIT signals have positive expectancy after costs on out-of-sample data. That is
  an empirical question your own backtester is well built enough to answer, and
  no amount of code I write can answer it in advance.

*Educational tooling, not financial advice.*
