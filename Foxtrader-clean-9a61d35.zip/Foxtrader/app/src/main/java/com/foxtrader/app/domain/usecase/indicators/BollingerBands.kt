package com.foxtrader.app.domain.usecase.indicators

import com.foxtrader.app.domain.model.Candle
import javax.inject.Inject
import kotlin.math.sqrt

/**
 * Bollinger Bands — volatility envelope around a moving average.
 *
 * Middle = SMA(period)
 * Upper  = Middle + stdDev * multiplier
 * Lower  = Middle - stdDev * multiplier
 *
 * Also provides:
 * - %B (position within bands: 0 = lower, 1 = upper)
 * - Bandwidth (band width relative to middle — volatility proxy)
 * - Squeeze detection (low bandwidth = pending breakout)
 */
class BollingerBands @Inject constructor() {

    data class BollingerResult(
        val middle: DoubleArray,
        val upper: DoubleArray,
        val lower: DoubleArray,
        val percentB: DoubleArray,
        val bandwidth: DoubleArray,
    )

    fun calculate(
        candles: List<Candle>,
        period: Int = 20,
        multiplier: Double = 2.0,
    ): BollingerResult = calculateIncremental(candles, previous = null, recomputeFrom = 0, period = period, multiplier = multiplier)

    fun calculateIncremental(
        candles: List<Candle>,
        previous: BollingerResult?,
        recomputeFrom: Int,
        period: Int = 20,
        multiplier: Double = 2.0,
    ): BollingerResult {
        val n = candles.size
        val middle = DoubleArray(n)
        val upper = DoubleArray(n)
        val lower = DoubleArray(n)
        val percentB = DoubleArray(n)
        val bandwidth = DoubleArray(n)
        if (n == 0) return BollingerResult(middle, upper, lower, percentB, bandwidth)

        // period == 0 makes the window `maxOf(0, i + 1)..i` empty, so
        // `sum / count` divides by zero and every band becomes NaN — which then
        // renders as an invisible/garbage overlay rather than an error.
        @Suppress("NAME_SHADOWING") val period = period.coerceAtLeast(1)

        val requestedStart = if (previous != null && recomputeFrom > 0) {
            maxOf(0, recomputeFrom - period + 1)
        } else {
            0
        }
        // `SAFETY` Only resume when the previous snapshot covers the resume
        // point (and has every band series at that length). A short snapshot
        // previously skipped the copy but kept startIndex > 0, leaving a
        // zeroed prefix that rendered bands at price 0 and wrecked auto-scale.
        val canReuse = previous != null &&
            requestedStart > 0 &&
            previous.middle.size >= requestedStart &&
            previous.upper.size >= requestedStart &&
            previous.lower.size >= requestedStart &&
            previous.percentB.size >= requestedStart &&
            previous.bandwidth.size >= requestedStart
        val startIndex = if (canReuse) requestedStart else 0
        if (canReuse && previous != null) {
            System.arraycopy(previous.middle, 0, middle, 0, startIndex)
            System.arraycopy(previous.upper, 0, upper, 0, startIndex)
            System.arraycopy(previous.lower, 0, lower, 0, startIndex)
            System.arraycopy(previous.percentB, 0, percentB, 0, startIndex)
            System.arraycopy(previous.bandwidth, 0, bandwidth, 0, startIndex)
        }

        for (i in startIndex until n) {
            val start = maxOf(0, i - period + 1)
            var sum = 0.0
            for (j in start..i) sum += candles[j].close
            val count = i - start + 1
            val mean = sum / count
            var varianceSum = 0.0
            for (j in start..i) {
                val diff = candles[j].close - mean
                varianceSum += diff * diff
            }
            val sd = sqrt(varianceSum / count)

            middle[i] = mean
            upper[i] = mean + sd * multiplier
            lower[i] = mean - sd * multiplier
            val bandRange = (upper[i] - lower[i]).coerceAtLeast(1e-9)
            percentB[i] = (candles[i].close - lower[i]) / bandRange
            bandwidth[i] = if (mean != 0.0) (upper[i] - lower[i]) / mean else 0.0
        }
        return BollingerResult(middle, upper, lower, percentB, bandwidth)
    }

    /**
     * Detect a "squeeze" — bandwidth at a local minimum over [lookback] bars,
     * indicating compressed volatility that often precedes a breakout.
     */
    fun isSqueeze(result: BollingerResult, lookback: Int = 50): Boolean {
        val bw = result.bandwidth
        if (bw.size < lookback) return false
        val recent = bw.takeLast(lookback)
        val current = bw.last()
        val minBw = recent.min()
        return current <= minBw * 1.05 // within 5% of the lowest bandwidth
    }
}
