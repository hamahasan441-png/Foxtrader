package com.foxtrader.app.di

import com.foxtrader.app.data.repository.AlertRepositoryImpl
import com.foxtrader.app.data.repository.AuthRepositoryImpl
import com.foxtrader.app.data.repository.DrawingRepositoryImpl
import com.foxtrader.app.data.repository.DerivRepositoryImpl
import com.foxtrader.app.data.repository.JournalRepositoryImpl
import com.foxtrader.app.data.repository.LitXSignalRepositoryImpl
import com.foxtrader.app.data.repository.MarketSymbolDirectoryImpl
import com.foxtrader.app.data.repository.RoutingMarketRepository
import com.foxtrader.app.data.repository.WatchlistRepositoryImpl
import com.foxtrader.app.domain.repository.AlertRepository
import com.foxtrader.app.domain.repository.AuthRepository
import com.foxtrader.app.domain.repository.DrawingRepository
import com.foxtrader.app.domain.repository.DerivRepository
import com.foxtrader.app.domain.repository.JournalRepository
import com.foxtrader.app.domain.repository.LitXSignalRepository
import com.foxtrader.app.domain.repository.MarketRepository
import com.foxtrader.app.domain.repository.MarketSymbolDirectory
import com.foxtrader.app.domain.repository.WatchlistRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindMarketRepository(impl: RoutingMarketRepository): MarketRepository

    @Binds
    @Singleton
    abstract fun bindMarketSymbolDirectory(impl: MarketSymbolDirectoryImpl): MarketSymbolDirectory

    @Binds
    @Singleton
    abstract fun bindAuthRepository(impl: AuthRepositoryImpl): AuthRepository

    @Binds
    @Singleton
    abstract fun bindJournalRepository(impl: JournalRepositoryImpl): JournalRepository

    @Binds
    @Singleton
    abstract fun bindDrawingRepository(impl: DrawingRepositoryImpl): DrawingRepository

    @Binds
    @Singleton
    abstract fun bindAlertRepository(impl: AlertRepositoryImpl): AlertRepository

    @Binds
    @Singleton
    abstract fun bindWatchlistRepository(impl: WatchlistRepositoryImpl): WatchlistRepository

    @Binds
    @Singleton
    abstract fun bindLitXSignalRepository(impl: LitXSignalRepositoryImpl): LitXSignalRepository

    @Binds
    @Singleton
    abstract fun bindDerivRepository(impl: DerivRepositoryImpl): DerivRepository
}
